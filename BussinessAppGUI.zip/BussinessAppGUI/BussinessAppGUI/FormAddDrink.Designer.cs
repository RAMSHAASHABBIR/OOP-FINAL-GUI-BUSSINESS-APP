﻿namespace BussinessAppGUI
{
    partial class FormAddDrink
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.LblDrinkName = new System.Windows.Forms.Label();
            this.LblDrinkPrice = new System.Windows.Forms.Label();
            this.LblDrinkStock = new System.Windows.Forms.Label();
            this.TxtDrinkName = new System.Windows.Forms.TextBox();
            this.TxtDrinkPrice = new System.Windows.Forms.TextBox();
            this.TxtDrinkStock = new System.Windows.Forms.TextBox();
            this.BtnGoBack = new System.Windows.Forms.Button();
            this.BtnToAddProductToList = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.ThemePage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.LblDrinkName, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.LblDrinkPrice, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.LblDrinkStock, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.TxtDrinkName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.TxtDrinkPrice, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.TxtDrinkStock, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnToAddProductToList, 1, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(840, 456);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // LblDrinkName
            // 
            this.LblDrinkName.AutoSize = true;
            this.LblDrinkName.BackColor = System.Drawing.Color.Khaki;
            this.LblDrinkName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblDrinkName.Location = new System.Drawing.Point(170, 30);
            this.LblDrinkName.Margin = new System.Windows.Forms.Padding(170, 30, 20, 10);
            this.LblDrinkName.Name = "LblDrinkName";
            this.LblDrinkName.Size = new System.Drawing.Size(182, 25);
            this.LblDrinkName.TabIndex = 1;
            this.LblDrinkName.Text = "Enter product name";
            // 
            // LblDrinkPrice
            // 
            this.LblDrinkPrice.AutoSize = true;
            this.LblDrinkPrice.BackColor = System.Drawing.Color.Khaki;
            this.LblDrinkPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblDrinkPrice.Location = new System.Drawing.Point(170, 98);
            this.LblDrinkPrice.Margin = new System.Windows.Forms.Padding(170, 30, 20, 10);
            this.LblDrinkPrice.Name = "LblDrinkPrice";
            this.LblDrinkPrice.Size = new System.Drawing.Size(175, 25);
            this.LblDrinkPrice.TabIndex = 2;
            this.LblDrinkPrice.Text = "Enter product price";
            // 
            // LblDrinkStock
            // 
            this.LblDrinkStock.AutoSize = true;
            this.LblDrinkStock.BackColor = System.Drawing.Color.Khaki;
            this.LblDrinkStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblDrinkStock.Location = new System.Drawing.Point(170, 166);
            this.LblDrinkStock.Margin = new System.Windows.Forms.Padding(170, 30, 20, 10);
            this.LblDrinkStock.Name = "LblDrinkStock";
            this.LblDrinkStock.Size = new System.Drawing.Size(179, 25);
            this.LblDrinkStock.TabIndex = 3;
            this.LblDrinkStock.Text = "Enter product stock";
            // 
            // TxtDrinkName
            // 
            this.TxtDrinkName.BackColor = System.Drawing.Color.Khaki;
            this.TxtDrinkName.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtDrinkName.Location = new System.Drawing.Point(440, 25);
            this.TxtDrinkName.Margin = new System.Windows.Forms.Padding(20, 25, 10, 3);
            this.TxtDrinkName.Name = "TxtDrinkName";
            this.TxtDrinkName.Size = new System.Drawing.Size(292, 36);
            this.TxtDrinkName.TabIndex = 4;
            // 
            // TxtDrinkPrice
            // 
            this.TxtDrinkPrice.BackColor = System.Drawing.Color.Khaki;
            this.TxtDrinkPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtDrinkPrice.Location = new System.Drawing.Point(440, 93);
            this.TxtDrinkPrice.Margin = new System.Windows.Forms.Padding(20, 25, 10, 3);
            this.TxtDrinkPrice.Name = "TxtDrinkPrice";
            this.TxtDrinkPrice.Size = new System.Drawing.Size(292, 36);
            this.TxtDrinkPrice.TabIndex = 5;
            // 
            // TxtDrinkStock
            // 
            this.TxtDrinkStock.BackColor = System.Drawing.Color.Khaki;
            this.TxtDrinkStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtDrinkStock.Location = new System.Drawing.Point(440, 161);
            this.TxtDrinkStock.Margin = new System.Windows.Forms.Padding(20, 25, 10, 3);
            this.TxtDrinkStock.Name = "TxtDrinkStock";
            this.TxtDrinkStock.Size = new System.Drawing.Size(292, 36);
            this.TxtDrinkStock.TabIndex = 6;
            this.TxtDrinkStock.TextChanged += new System.EventHandler(this.TxtDrinkStock_TextChanged);
            // 
            // BtnGoBack
            // 
            this.BtnGoBack.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnGoBack.Location = new System.Drawing.Point(50, 234);
            this.BtnGoBack.Margin = new System.Windows.Forms.Padding(50, 30, 30, 10);
            this.BtnGoBack.Name = "BtnGoBack";
            this.BtnGoBack.Size = new System.Drawing.Size(94, 44);
            this.BtnGoBack.TabIndex = 8;
            this.BtnGoBack.Text = "Go Back";
            this.BtnGoBack.UseVisualStyleBackColor = false;
            this.BtnGoBack.Click += new System.EventHandler(this.BtnGoBack_Click);
            // 
            // BtnToAddProductToList
            // 
            this.BtnToAddProductToList.BackColor = System.Drawing.Color.Khaki;
            this.BtnToAddProductToList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnToAddProductToList.Location = new System.Drawing.Point(637, 234);
            this.BtnToAddProductToList.Margin = new System.Windows.Forms.Padding(217, 30, 30, 10);
            this.BtnToAddProductToList.Name = "BtnToAddProductToList";
            this.BtnToAddProductToList.Size = new System.Drawing.Size(94, 44);
            this.BtnToAddProductToList.TabIndex = 9;
            this.BtnToAddProductToList.Text = "Enter";
            this.BtnToAddProductToList.UseVisualStyleBackColor = false;
            this.BtnToAddProductToList.Click += new System.EventHandler(this.BtnToAddProductToList_Click);
            // 
            // FormAddDrink
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(840, 456);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormAddDrink";
            this.Text = "FormAddDrink";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormAddDrink_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label LblDrinkName;
        private System.Windows.Forms.Label LblDrinkPrice;
        private System.Windows.Forms.Label LblDrinkStock;
        private System.Windows.Forms.TextBox TxtDrinkName;
        private System.Windows.Forms.TextBox TxtDrinkPrice;
        private System.Windows.Forms.TextBox TxtDrinkStock;
        private System.Windows.Forms.Button BtnGoBack;
        private System.Windows.Forms.Button BtnToAddProductToList;
    }
}