﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    public partial class FormDeleteProduct : Form
    {
        public FormDeleteProduct()
        {
            InitializeComponent();
        }
        private void dataGridDeleteProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int s = dataGridDeleteProduct.SelectedCells[0].RowIndex;
            string name = (string)dataGridDeleteProduct.Rows[s].Cells[0].Value;
            bool check = MenuItemDL.Deletingproduct(name);
            loadData();
            if (check == true)
            {
                MessageBox.Show("deleted Successfully");
                FormAdminMenu formAdminMenu = new FormAdminMenu();
                this.Hide();
                formAdminMenu.Show();
            }

        }

        private void BtnGoBack_Click_1(object sender, EventArgs e)
        {
            FormAdminMenu formAdminMenu = new FormAdminMenu();
            this.Hide();
            formAdminMenu.Show();
        }

        private void FormDeleteProduct_Load(object sender, EventArgs e)
        {
            loadData();
        }
        void loadData()
        {
            dataGridDeleteProduct.DataSource = null;
            dataGridDeleteProduct.DataSource = MenuItemDL.products;
            dataGridDeleteProduct.Refresh();
        }

        private void BtnToMenuPage_Click(object sender, EventArgs e)
        {
            FormAdminMenu formAdminMenu = new FormAdminMenu();
            this.Hide();
            formAdminMenu.Show();
        }
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

    }
}
