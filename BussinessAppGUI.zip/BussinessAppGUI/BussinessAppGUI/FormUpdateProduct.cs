﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace BussinessAppGUI
{
    public partial class FormUpdateProduct : Form
    {
        public static int check;
        public FormUpdateProduct()
        {
            InitializeComponent();
        }

        private void FormUpdateProduct_Load(object sender, EventArgs e)
        {
            dataGridUpdate.DataSource = null;
            dataGridUpdate.DataSource = MenuItemDL.products;
            dataGridUpdate.Refresh();
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormAdminMenu formAdminMenu = new FormAdminMenu();
            this.Hide();
            formAdminMenu.Show();
        }

        private void dataGridUpdate_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int s = dataGridUpdate.SelectedCells[0].RowIndex;
            string name = (string)dataGridUpdate.Rows[s].Cells[0].Value;
            check = MenuItemDL.CheckProductExistAddingStock(name);
            if (check == -1)
            {
                MessageBox.Show("Product doesn't exist");
            }
            else
            {
                FormUpdatingFood formUpdatingFood = new FormUpdatingFood();
                this.Hide();
                formUpdatingFood.Show();
            }
        }

        private void dataGridUpdate_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
