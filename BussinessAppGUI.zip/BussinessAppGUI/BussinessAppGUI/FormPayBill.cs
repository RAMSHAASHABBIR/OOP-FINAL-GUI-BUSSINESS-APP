﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    public partial class FormPayBill : Form
    {
        public FormPayBill()
        {
            InitializeComponent();
        }

        private void BtnEnter_Click(object sender, EventArgs e)
        {
            if(BtnYes.Checked)
            {
                OrdersDL.orders.Clear();
               
                OrdersDL.WriteOrdersToFile();
                MessageBox.Show("Your bill is paid succesfully");
                FormCustomerMenu formCustomerMenu = new FormCustomerMenu();
                this.Hide();
                formCustomerMenu.Show();
            }
            else if(BtnNo.Checked)
            {
                FormCustomerMenu formCustomerMenu = new FormCustomerMenu();
                this.Hide();
                formCustomerMenu.Show();
            }
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormCustomerMenu formCustomerMenu = new FormCustomerMenu();
            this.Hide();
            formCustomerMenu.Show();
        }

        private void FormPayBill_Load(object sender, EventArgs e)
        {

        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
