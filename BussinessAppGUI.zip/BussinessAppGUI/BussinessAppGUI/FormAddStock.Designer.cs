﻿namespace BussinessAppGUI
{
    partial class FormAddStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.LblAddStockOfProduct = new System.Windows.Forms.Label();
            this.BtnCheckProductToAdd = new System.Windows.Forms.Button();
            this.BtnGoBack = new System.Windows.Forms.Button();
            this.LblFoodStockAdd = new System.Windows.Forms.Label();
            this.BtnGoBack2 = new System.Windows.Forms.Button();
            this.BtnAddingStock = new System.Windows.Forms.Button();
            this.TxtAddStockOfProduct = new System.Windows.Forms.TextBox();
            this.TxtFoodStockAdd = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.ThemePage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.LblAddStockOfProduct, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnCheckProductToAdd, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.LblFoodStockAdd, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack2, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnAddingStock, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.TxtAddStockOfProduct, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.TxtFoodStockAdd, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.8035F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.41011F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.20255F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.41011F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.17373F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // LblAddStockOfProduct
            // 
            this.LblAddStockOfProduct.AutoSize = true;
            this.LblAddStockOfProduct.BackColor = System.Drawing.Color.Khaki;
            this.LblAddStockOfProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblAddStockOfProduct.Location = new System.Drawing.Point(170, 30);
            this.LblAddStockOfProduct.Margin = new System.Windows.Forms.Padding(170, 30, 20, 10);
            this.LblAddStockOfProduct.Name = "LblAddStockOfProduct";
            this.LblAddStockOfProduct.Size = new System.Drawing.Size(182, 25);
            this.LblAddStockOfProduct.TabIndex = 2;
            this.LblAddStockOfProduct.Text = "Enter product name";
            // 
            // BtnCheckProductToAdd
            // 
            this.BtnCheckProductToAdd.BackColor = System.Drawing.Color.Khaki;
            this.BtnCheckProductToAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnCheckProductToAdd.Location = new System.Drawing.Point(617, 109);
            this.BtnCheckProductToAdd.Margin = new System.Windows.Forms.Padding(217, 20, 30, 10);
            this.BtnCheckProductToAdd.Name = "BtnCheckProductToAdd";
            this.BtnCheckProductToAdd.Size = new System.Drawing.Size(94, 43);
            this.BtnCheckProductToAdd.TabIndex = 10;
            this.BtnCheckProductToAdd.Text = "Enter";
            this.BtnCheckProductToAdd.UseVisualStyleBackColor = false;
            this.BtnCheckProductToAdd.Click += new System.EventHandler(this.BtnToAddStock_Click);
            // 
            // BtnGoBack
            // 
            this.BtnGoBack.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnGoBack.Location = new System.Drawing.Point(50, 109);
            this.BtnGoBack.Margin = new System.Windows.Forms.Padding(50, 20, 30, 10);
            this.BtnGoBack.Name = "BtnGoBack";
            this.BtnGoBack.Size = new System.Drawing.Size(94, 43);
            this.BtnGoBack.TabIndex = 11;
            this.BtnGoBack.Text = "Go Back";
            this.BtnGoBack.UseVisualStyleBackColor = false;
            this.BtnGoBack.Click += new System.EventHandler(this.BtnGoBack_Click);
            // 
            // LblFoodStockAdd
            // 
            this.LblFoodStockAdd.AutoSize = true;
            this.LblFoodStockAdd.BackColor = System.Drawing.Color.Khaki;
            this.LblFoodStockAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblFoodStockAdd.Location = new System.Drawing.Point(170, 192);
            this.LblFoodStockAdd.Margin = new System.Windows.Forms.Padding(170, 30, 20, 10);
            this.LblFoodStockAdd.Name = "LblFoodStockAdd";
            this.LblFoodStockAdd.Size = new System.Drawing.Size(179, 25);
            this.LblFoodStockAdd.TabIndex = 12;
            this.LblFoodStockAdd.Text = "Enter product stock";
            this.LblFoodStockAdd.Visible = false;
            // 
            // BtnGoBack2
            // 
            this.BtnGoBack2.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnGoBack2.Location = new System.Drawing.Point(50, 272);
            this.BtnGoBack2.Margin = new System.Windows.Forms.Padding(50, 20, 30, 10);
            this.BtnGoBack2.Name = "BtnGoBack2";
            this.BtnGoBack2.Size = new System.Drawing.Size(94, 43);
            this.BtnGoBack2.TabIndex = 14;
            this.BtnGoBack2.Text = "Go Back";
            this.BtnGoBack2.UseVisualStyleBackColor = false;
            this.BtnGoBack2.Visible = false;
            this.BtnGoBack2.Click += new System.EventHandler(this.BtnGoBack2_Click);
            // 
            // BtnAddingStock
            // 
            this.BtnAddingStock.BackColor = System.Drawing.Color.Khaki;
            this.BtnAddingStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnAddingStock.Location = new System.Drawing.Point(617, 272);
            this.BtnAddingStock.Margin = new System.Windows.Forms.Padding(217, 20, 30, 10);
            this.BtnAddingStock.Name = "BtnAddingStock";
            this.BtnAddingStock.Size = new System.Drawing.Size(94, 43);
            this.BtnAddingStock.TabIndex = 15;
            this.BtnAddingStock.Text = "Enter";
            this.BtnAddingStock.UseVisualStyleBackColor = false;
            this.BtnAddingStock.Visible = false;
            this.BtnAddingStock.Click += new System.EventHandler(this.BtnAddingStock_Click);
            // 
            // TxtAddStockOfProduct
            // 
            this.TxtAddStockOfProduct.BackColor = System.Drawing.Color.Khaki;
            this.TxtAddStockOfProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtAddStockOfProduct.Location = new System.Drawing.Point(420, 187);
            this.TxtAddStockOfProduct.Margin = new System.Windows.Forms.Padding(20, 25, 10, 3);
            this.TxtAddStockOfProduct.Name = "TxtAddStockOfProduct";
            this.TxtAddStockOfProduct.Size = new System.Drawing.Size(292, 36);
            this.TxtAddStockOfProduct.TabIndex = 5;
            this.TxtAddStockOfProduct.Visible = false;
            // 
            // TxtFoodStockAdd
            // 
            this.TxtFoodStockAdd.BackColor = System.Drawing.Color.Khaki;
            this.TxtFoodStockAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtFoodStockAdd.Location = new System.Drawing.Point(420, 25);
            this.TxtFoodStockAdd.Margin = new System.Windows.Forms.Padding(20, 25, 10, 3);
            this.TxtFoodStockAdd.Name = "TxtFoodStockAdd";
            this.TxtFoodStockAdd.Size = new System.Drawing.Size(292, 36);
            this.TxtFoodStockAdd.TabIndex = 13;
            // 
            // FormAddStock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormAddStock";
            this.Text = "FormAddStock";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormAddStock_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label LblAddStockOfProduct;
        private System.Windows.Forms.TextBox TxtAddStockOfProduct;
        private System.Windows.Forms.Button BtnCheckProductToAdd;
        private System.Windows.Forms.Button BtnGoBack;
        private System.Windows.Forms.Label LblFoodStockAdd;
        private System.Windows.Forms.TextBox TxtFoodStockAdd;
        private System.Windows.Forms.Button BtnGoBack2;
        private System.Windows.Forms.Button BtnAddingStock;
    }
}