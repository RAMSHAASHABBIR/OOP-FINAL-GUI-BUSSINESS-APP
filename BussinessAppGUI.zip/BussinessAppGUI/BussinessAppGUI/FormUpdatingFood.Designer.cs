﻿namespace BussinessAppGUI
{
    partial class FormUpdatingFood
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.LblUpdateName = new System.Windows.Forms.Label();
            this.LblUpdatePrice = new System.Windows.Forms.Label();
            this.TxtUpdateName = new System.Windows.Forms.TextBox();
            this.TxtUpdatePrice = new System.Windows.Forms.TextBox();
            this.BtnGoBack = new System.Windows.Forms.Button();
            this.BtnToUpdate = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.ThemePage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.LblUpdateName, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.LblUpdatePrice, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.TxtUpdateName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.TxtUpdatePrice, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.BtnToUpdate, 1, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.18182F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.18182F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.72727F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.90909F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // LblUpdateName
            // 
            this.LblUpdateName.AutoSize = true;
            this.LblUpdateName.BackColor = System.Drawing.Color.Khaki;
            this.LblUpdateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblUpdateName.Location = new System.Drawing.Point(170, 30);
            this.LblUpdateName.Margin = new System.Windows.Forms.Padding(170, 30, 20, 10);
            this.LblUpdateName.Name = "LblUpdateName";
            this.LblUpdateName.Size = new System.Drawing.Size(182, 25);
            this.LblUpdateName.TabIndex = 2;
            this.LblUpdateName.Text = "Enter product name";
            this.LblUpdateName.Click += new System.EventHandler(this.LblUpdateName_Click);
            // 
            // LblUpdatePrice
            // 
            this.LblUpdatePrice.AutoSize = true;
            this.LblUpdatePrice.BackColor = System.Drawing.Color.Khaki;
            this.LblUpdatePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblUpdatePrice.Location = new System.Drawing.Point(170, 111);
            this.LblUpdatePrice.Margin = new System.Windows.Forms.Padding(170, 30, 20, 10);
            this.LblUpdatePrice.Name = "LblUpdatePrice";
            this.LblUpdatePrice.Size = new System.Drawing.Size(175, 25);
            this.LblUpdatePrice.TabIndex = 3;
            this.LblUpdatePrice.Text = "Enter product price";
            // 
            // TxtUpdateName
            // 
            this.TxtUpdateName.BackColor = System.Drawing.Color.Khaki;
            this.TxtUpdateName.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtUpdateName.Location = new System.Drawing.Point(420, 25);
            this.TxtUpdateName.Margin = new System.Windows.Forms.Padding(20, 25, 10, 3);
            this.TxtUpdateName.Name = "TxtUpdateName";
            this.TxtUpdateName.Size = new System.Drawing.Size(292, 36);
            this.TxtUpdateName.TabIndex = 5;
            // 
            // TxtUpdatePrice
            // 
            this.TxtUpdatePrice.BackColor = System.Drawing.Color.Khaki;
            this.TxtUpdatePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtUpdatePrice.Location = new System.Drawing.Point(420, 106);
            this.TxtUpdatePrice.Margin = new System.Windows.Forms.Padding(20, 25, 10, 3);
            this.TxtUpdatePrice.Name = "TxtUpdatePrice";
            this.TxtUpdatePrice.Size = new System.Drawing.Size(292, 36);
            this.TxtUpdatePrice.TabIndex = 6;
            // 
            // BtnGoBack
            // 
            this.BtnGoBack.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnGoBack.Location = new System.Drawing.Point(50, 192);
            this.BtnGoBack.Margin = new System.Windows.Forms.Padding(50, 30, 30, 10);
            this.BtnGoBack.Name = "BtnGoBack";
            this.BtnGoBack.Size = new System.Drawing.Size(94, 44);
            this.BtnGoBack.TabIndex = 9;
            this.BtnGoBack.Text = "Go Back";
            this.BtnGoBack.UseVisualStyleBackColor = false;
            this.BtnGoBack.Click += new System.EventHandler(this.BtnGoBack_Click);
            // 
            // BtnToUpdate
            // 
            this.BtnToUpdate.BackColor = System.Drawing.Color.Khaki;
            this.BtnToUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnToUpdate.Location = new System.Drawing.Point(617, 192);
            this.BtnToUpdate.Margin = new System.Windows.Forms.Padding(217, 30, 30, 10);
            this.BtnToUpdate.Name = "BtnToUpdate";
            this.BtnToUpdate.Size = new System.Drawing.Size(94, 44);
            this.BtnToUpdate.TabIndex = 10;
            this.BtnToUpdate.Text = "Enter";
            this.BtnToUpdate.UseVisualStyleBackColor = false;
            this.BtnToUpdate.Click += new System.EventHandler(this.BtnToUpdate_Click);
            // 
            // FormUpdatingFood
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormUpdatingFood";
            this.Text = "FormUpdatingFood";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormUpdatingFood_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label LblUpdateName;
        private System.Windows.Forms.Label LblUpdatePrice;
        private System.Windows.Forms.TextBox TxtUpdateName;
        private System.Windows.Forms.TextBox TxtUpdatePrice;
        private System.Windows.Forms.Button BtnGoBack;
        private System.Windows.Forms.Button BtnToUpdate;
    }
}