﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    public partial class FormViewOrders : Form
    {
        public FormViewOrders()
        {
            InitializeComponent();
        }

        private void FormViewOrders_Load(object sender, EventArgs e)
        {
            OrdersBL order = OrdersDL.getList(Program.username);
            order.username = Program.username;
            GridOrders.DataSource = null;
            GridOrders.DataSource = order.orders.ConvertAll(x=>new {Order=x});
            GridOrders.Refresh();
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormCustomerMenu formCustomerMenu = new FormCustomerMenu();
            this.Hide();
            formCustomerMenu.Show();
        }
    }
}
 