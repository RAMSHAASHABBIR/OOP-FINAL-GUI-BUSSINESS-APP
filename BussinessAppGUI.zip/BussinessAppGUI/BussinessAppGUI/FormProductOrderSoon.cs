﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BussinessAppGUI
{
    public partial class FormProductOrderSoon : Form
    {
        public FormProductOrderSoon()
        {
            InitializeComponent();
        }
        public void FormProductOrderSoon_Load(object sender, EventArgs e)
        {

            GridPrintProductOrderSoon.DataSource = null;
            GridPrintProductOrderSoon.DataSource = getProductToOrderSoon();
            GridPrintProductOrderSoon.Refresh();
        }
        private List<MenuItemBL> getProductToOrderSoon()
        {
            List<MenuItemBL> productToBeOrder = new List<MenuItemBL>();
            for (int j = 0; j < MenuItemDL.products.Count(); j++)
            {
                if (int.Parse(MenuItemDL.products[j].GetStockquantity()) < 6)
                {
                    productToBeOrder.Add(MenuItemDL.products[j]);
                }
            }
            return productToBeOrder;
            
        }
        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormAdminMenu adminMenu = new FormAdminMenu();
            this.Hide();
            adminMenu.Show();
        }
        private void GridPrintProductOrderSoon_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
