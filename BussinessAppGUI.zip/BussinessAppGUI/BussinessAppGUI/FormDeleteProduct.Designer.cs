﻿namespace BussinessAppGUI
{
    partial class FormDeleteProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.LblDeleteProduct = new System.Windows.Forms.Label();
            this.dataGridDeleteProduct = new System.Windows.Forms.DataGridView();
            this.BtnGoBack = new System.Windows.Forms.Button();
            this.BtnToMenuPage = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridDeleteProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.ThemePage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.LblDeleteProduct, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.dataGridDeleteProduct, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.BtnToMenuPage, 1, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(834, 486);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // LblDeleteProduct
            // 
            this.LblDeleteProduct.AutoSize = true;
            this.LblDeleteProduct.BackColor = System.Drawing.Color.Khaki;
            this.LblDeleteProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.LblDeleteProduct.Location = new System.Drawing.Point(236, 30);
            this.LblDeleteProduct.Margin = new System.Windows.Forms.Padding(70, 30, 3, 0);
            this.LblDeleteProduct.Name = "LblDeleteProduct";
            this.LblDeleteProduct.Size = new System.Drawing.Size(337, 26);
            this.LblDeleteProduct.TabIndex = 17;
            this.LblDeleteProduct.Text = "SELECT PRODUCT TO DELETE";
            // 
            // dataGridDeleteProduct
            // 
            this.dataGridDeleteProduct.BackgroundColor = System.Drawing.Color.Khaki;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Khaki;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Goldenrod;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridDeleteProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridDeleteProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Khaki;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Goldenrod;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridDeleteProduct.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridDeleteProduct.EnableHeadersVisualStyles = false;
            this.dataGridDeleteProduct.Location = new System.Drawing.Point(169, 100);
            this.dataGridDeleteProduct.Name = "dataGridDeleteProduct";
            this.dataGridDeleteProduct.RowHeadersVisible = false;
            this.dataGridDeleteProduct.Size = new System.Drawing.Size(494, 188);
            this.dataGridDeleteProduct.TabIndex = 11;
            this.dataGridDeleteProduct.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridDeleteProduct_CellClick);
            // 
            // BtnGoBack
            // 
            this.BtnGoBack.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnGoBack.Location = new System.Drawing.Point(70, 321);
            this.BtnGoBack.Margin = new System.Windows.Forms.Padding(70, 30, 3, 10);
            this.BtnGoBack.Name = "BtnGoBack";
            this.BtnGoBack.Size = new System.Drawing.Size(93, 44);
            this.BtnGoBack.TabIndex = 15;
            this.BtnGoBack.Text = "Go Back";
            this.BtnGoBack.UseVisualStyleBackColor = false;
            this.BtnGoBack.Click += new System.EventHandler(this.BtnGoBack_Click_1);
            // 
            // BtnToMenuPage
            // 
            this.BtnToMenuPage.BackColor = System.Drawing.Color.Khaki;
            this.BtnToMenuPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnToMenuPage.Location = new System.Drawing.Point(546, 321);
            this.BtnToMenuPage.Margin = new System.Windows.Forms.Padding(380, 30, 10, 10);
            this.BtnToMenuPage.Name = "BtnToMenuPage";
            this.BtnToMenuPage.Size = new System.Drawing.Size(94, 44);
            this.BtnToMenuPage.TabIndex = 16;
            this.BtnToMenuPage.Text = "Enter";
            this.BtnToMenuPage.UseVisualStyleBackColor = false;
            this.BtnToMenuPage.Click += new System.EventHandler(this.BtnToMenuPage_Click);
            // 
            // FormDeleteProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 486);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormDeleteProduct";
            this.Text = "FormDeleteProduct";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormDeleteProduct_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridDeleteProduct)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView dataGridDeleteProduct;
        private System.Windows.Forms.Button BtnGoBack;
        private System.Windows.Forms.Button BtnToMenuPage;
        private System.Windows.Forms.Label LblDeleteProduct;
    }
}