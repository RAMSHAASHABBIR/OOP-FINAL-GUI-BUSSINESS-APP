﻿namespace BussinessAppGUI
{
    partial class FormAdminMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.BtnAddDrink = new System.Windows.Forms.Button();
            this.BtnAddFood = new System.Windows.Forms.Button();
            this.BtnViewDrink = new System.Windows.Forms.Button();
            this.BtnViewFood = new System.Windows.Forms.Button();
            this.BtnUpdateProduct = new System.Windows.Forms.Button();
            this.BtnDeleteProduct = new System.Windows.Forms.Button();
            this.BtnProductOrderSoon = new System.Windows.Forms.Button();
            this.BtnAddingStock = new System.Windows.Forms.Button();
            this.BtnGoBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.AdminPage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.BtnAddDrink, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.BtnAddFood, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.BtnViewDrink, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnViewFood, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.BtnUpdateProduct, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.BtnDeleteProduct, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.BtnProductOrderSoon, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.BtnAddingStock, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // BtnAddDrink
            // 
            this.BtnAddDrink.BackColor = System.Drawing.Color.Khaki;
            this.BtnAddDrink.Location = new System.Drawing.Point(3, 48);
            this.BtnAddDrink.Name = "BtnAddDrink";
            this.BtnAddDrink.Size = new System.Drawing.Size(260, 39);
            this.BtnAddDrink.TabIndex = 2;
            this.BtnAddDrink.Text = "Add Drink";
            this.BtnAddDrink.UseVisualStyleBackColor = false;
            this.BtnAddDrink.Click += new System.EventHandler(this.BtnAddDrink_Click);
            // 
            // BtnAddFood
            // 
            this.BtnAddFood.BackColor = System.Drawing.Color.Khaki;
            this.BtnAddFood.Location = new System.Drawing.Point(3, 93);
            this.BtnAddFood.Name = "BtnAddFood";
            this.BtnAddFood.Size = new System.Drawing.Size(260, 39);
            this.BtnAddFood.TabIndex = 1;
            this.BtnAddFood.Text = "Add Food";
            this.BtnAddFood.UseVisualStyleBackColor = false;
            this.BtnAddFood.Click += new System.EventHandler(this.BtnAddFood_Click);
            // 
            // BtnViewDrink
            // 
            this.BtnViewDrink.BackColor = System.Drawing.Color.Khaki;
            this.BtnViewDrink.Location = new System.Drawing.Point(3, 138);
            this.BtnViewDrink.Name = "BtnViewDrink";
            this.BtnViewDrink.Size = new System.Drawing.Size(260, 39);
            this.BtnViewDrink.TabIndex = 4;
            this.BtnViewDrink.Text = "View Drink Products";
            this.BtnViewDrink.UseVisualStyleBackColor = false;
            this.BtnViewDrink.Click += new System.EventHandler(this.BtnViewDrink_Click);
            // 
            // BtnViewFood
            // 
            this.BtnViewFood.BackColor = System.Drawing.Color.Khaki;
            this.BtnViewFood.Location = new System.Drawing.Point(3, 183);
            this.BtnViewFood.Name = "BtnViewFood";
            this.BtnViewFood.Size = new System.Drawing.Size(260, 39);
            this.BtnViewFood.TabIndex = 3;
            this.BtnViewFood.Text = "View Food Products";
            this.BtnViewFood.UseVisualStyleBackColor = false;
            this.BtnViewFood.Click += new System.EventHandler(this.BtnViewFood_Click);
            // 
            // BtnUpdateProduct
            // 
            this.BtnUpdateProduct.BackColor = System.Drawing.Color.Khaki;
            this.BtnUpdateProduct.Location = new System.Drawing.Point(3, 228);
            this.BtnUpdateProduct.Name = "BtnUpdateProduct";
            this.BtnUpdateProduct.Size = new System.Drawing.Size(260, 39);
            this.BtnUpdateProduct.TabIndex = 5;
            this.BtnUpdateProduct.Text = "Update Products";
            this.BtnUpdateProduct.UseVisualStyleBackColor = false;
            this.BtnUpdateProduct.Click += new System.EventHandler(this.BtnUpdateProduct_Click);
            // 
            // BtnDeleteProduct
            // 
            this.BtnDeleteProduct.BackColor = System.Drawing.Color.Khaki;
            this.BtnDeleteProduct.Location = new System.Drawing.Point(3, 273);
            this.BtnDeleteProduct.Name = "BtnDeleteProduct";
            this.BtnDeleteProduct.Size = new System.Drawing.Size(260, 39);
            this.BtnDeleteProduct.TabIndex = 6;
            this.BtnDeleteProduct.Text = "Delete Products";
            this.BtnDeleteProduct.UseVisualStyleBackColor = false;
            this.BtnDeleteProduct.Click += new System.EventHandler(this.BtnDeleteProduct_Click);
            // 
            // BtnProductOrderSoon
            // 
            this.BtnProductOrderSoon.BackColor = System.Drawing.Color.Khaki;
            this.BtnProductOrderSoon.Location = new System.Drawing.Point(3, 318);
            this.BtnProductOrderSoon.Name = "BtnProductOrderSoon";
            this.BtnProductOrderSoon.Size = new System.Drawing.Size(260, 39);
            this.BtnProductOrderSoon.TabIndex = 7;
            this.BtnProductOrderSoon.Text = "Soon Ordering Product";
            this.BtnProductOrderSoon.UseVisualStyleBackColor = false;
            this.BtnProductOrderSoon.Click += new System.EventHandler(this.BtnProductOrderSoon_Click);
            // 
            // BtnAddingStock
            // 
            this.BtnAddingStock.BackColor = System.Drawing.Color.Khaki;
            this.BtnAddingStock.Location = new System.Drawing.Point(3, 363);
            this.BtnAddingStock.Name = "BtnAddingStock";
            this.BtnAddingStock.Size = new System.Drawing.Size(260, 39);
            this.BtnAddingStock.TabIndex = 8;
            this.BtnAddingStock.Text = "Adding New Stock";
            this.BtnAddingStock.UseVisualStyleBackColor = false;
            this.BtnAddingStock.Click += new System.EventHandler(this.BtnAddingStock_Click);
            // 
            // BtnGoBack
            // 
            this.BtnGoBack.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack.Location = new System.Drawing.Point(3, 408);
            this.BtnGoBack.Name = "BtnGoBack";
            this.BtnGoBack.Size = new System.Drawing.Size(260, 39);
            this.BtnGoBack.TabIndex = 9;
            this.BtnGoBack.Text = "Go Back";
            this.BtnGoBack.UseVisualStyleBackColor = false;
            this.BtnGoBack.Click += new System.EventHandler(this.BtnGoBack_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Khaki;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label1.Location = new System.Drawing.Point(71, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(71, 10, 3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "WELCOME";
            // 
            // FormAdminMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormAdminMenu";
            this.Text = "AdminMenu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormAdminMenu_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnAddFood;
        private System.Windows.Forms.Button BtnAddDrink;
        private System.Windows.Forms.Button BtnViewFood;
        private System.Windows.Forms.Button BtnViewDrink;
        private System.Windows.Forms.Button BtnUpdateProduct;
        private System.Windows.Forms.Button BtnDeleteProduct;
        private System.Windows.Forms.Button BtnProductOrderSoon;
        private System.Windows.Forms.Button BtnAddingStock;
        private System.Windows.Forms.Button BtnGoBack;
    }
}