﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    public partial class FormProductTax : Form
    {
        public FormProductTax()
        {
            InitializeComponent();
        }
        private List<MenuItemBL>  ProductTax()
        {
            List<MenuItemBL> producttax = new List<MenuItemBL>();
           producttax = MenuItemDL.Tax();
            return producttax;
        }

        private void FormProductTax_Load(object sender, EventArgs e)
        {
            GridPrintTax.DataSource = null;
            GridPrintTax.DataSource = ProductTax();
            GridPrintTax.Refresh();
            GridPrintTax.Columns.Add("Tax","Tax");
            for(int i=0;i<MenuItemDL.products.Count;i++)
            {
                
                GridPrintTax.Rows[i].Cells[3].Value = MenuItemDL.calculateTax[i];
            } 

        }
       
        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormCustomerMenu formCustomerMenu = new FormCustomerMenu();
            this.Hide();
            formCustomerMenu.Show();
        }
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
