﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    public partial class FormViewFoodUser : Form
    {
        public FormViewFoodUser()
        {
            InitializeComponent();
        }
        private List<MenuItemBL> getFood()
        {
            List<MenuItemBL> food = new List<MenuItemBL>();
            foreach (var i in MenuItemDL.products)
            {
                if (i.GetType() == typeof(MenuItemFoodBL))
                {

                    food.Add(i);
                }
            }
            return food;
        }

        private void FormViewFoodUser_Load(object sender, EventArgs e)
        {
            GridPrintFoodUser.DataSource = null;
            GridPrintFoodUser.DataSource = getFood();
            GridPrintFoodUser.Refresh();
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormCustomerMenu formCustomerMenu = new FormCustomerMenu();
            this.Hide();
            formCustomerMenu.Show();
        }

        private void GridPrintFoodUser_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
