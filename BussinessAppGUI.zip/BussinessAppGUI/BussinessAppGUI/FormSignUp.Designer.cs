﻿namespace BussinessAppGUI
{
    partial class FormSignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.LblRole = new System.Windows.Forms.Label();
            this.TxtPassword = new System.Windows.Forms.TextBox();
            this.LblName = new System.Windows.Forms.Label();
            this.LblPassword = new System.Windows.Forms.Label();
            this.TxtName = new System.Windows.Forms.TextBox();
            this.BtnToAddToList = new System.Windows.Forms.Button();
            this.BtnGoBack = new System.Windows.Forms.Button();
            this.RdoBtnCustomer = new System.Windows.Forms.RadioButton();
            this.RdoBtnAdmin = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.TopPage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.LblRole, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.TxtPassword, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.LblName, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.LblPassword, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.TxtName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnToAddToList, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.RdoBtnCustomer, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.RdoBtnAdmin, 1, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.82498F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.82498F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.8642F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.35445F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.13138F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // LblRole
            // 
            this.LblRole.AutoSize = true;
            this.LblRole.BackColor = System.Drawing.Color.Khaki;
            this.LblRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblRole.Location = new System.Drawing.Point(210, 162);
            this.LblRole.Margin = new System.Windows.Forms.Padding(210, 30, 20, 10);
            this.LblRole.Name = "LblRole";
            this.LblRole.Size = new System.Drawing.Size(138, 25);
            this.LblRole.TabIndex = 4;
            this.LblRole.Text = "Enter your role";
            // 
            // TxtPassword
            // 
            this.TxtPassword.BackColor = System.Drawing.Color.Khaki;
            this.TxtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtPassword.Location = new System.Drawing.Point(420, 91);
            this.TxtPassword.Margin = new System.Windows.Forms.Padding(20, 25, 10, 3);
            this.TxtPassword.Name = "TxtPassword";
            this.TxtPassword.Size = new System.Drawing.Size(292, 36);
            this.TxtPassword.TabIndex = 3;
            this.TxtPassword.TextChanged += new System.EventHandler(this.TxtPassword_TextChanged);
            // 
            // LblName
            // 
            this.LblName.AutoSize = true;
            this.LblName.BackColor = System.Drawing.Color.Khaki;
            this.LblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblName.Location = new System.Drawing.Point(200, 30);
            this.LblName.Margin = new System.Windows.Forms.Padding(200, 30, 20, 10);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(155, 25);
            this.LblName.TabIndex = 0;
            this.LblName.Text = "Enter your name";
            this.LblName.Click += new System.EventHandler(this.LblName_Click);
            // 
            // LblPassword
            // 
            this.LblPassword.AutoSize = true;
            this.LblPassword.BackColor = System.Drawing.Color.Khaki;
            this.LblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblPassword.Location = new System.Drawing.Point(165, 96);
            this.LblPassword.Margin = new System.Windows.Forms.Padding(165, 30, 20, 10);
            this.LblPassword.Name = "LblPassword";
            this.LblPassword.Size = new System.Drawing.Size(190, 25);
            this.LblPassword.TabIndex = 1;
            this.LblPassword.Text = "Enter your password";
            this.LblPassword.Click += new System.EventHandler(this.LblPassword_Click);
            // 
            // TxtName
            // 
            this.TxtName.BackColor = System.Drawing.Color.Khaki;
            this.TxtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtName.Location = new System.Drawing.Point(420, 25);
            this.TxtName.Margin = new System.Windows.Forms.Padding(20, 25, 10, 3);
            this.TxtName.Name = "TxtName";
            this.TxtName.Size = new System.Drawing.Size(292, 36);
            this.TxtName.TabIndex = 2;
            // 
            // BtnToAddToList
            // 
            this.BtnToAddToList.BackColor = System.Drawing.Color.Khaki;
            this.BtnToAddToList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnToAddToList.Location = new System.Drawing.Point(617, 297);
            this.BtnToAddToList.Margin = new System.Windows.Forms.Padding(217, 30, 30, 10);
            this.BtnToAddToList.Name = "BtnToAddToList";
            this.BtnToAddToList.Size = new System.Drawing.Size(94, 44);
            this.BtnToAddToList.TabIndex = 6;
            this.BtnToAddToList.Text = "Enter";
            this.BtnToAddToList.UseVisualStyleBackColor = false;
            this.BtnToAddToList.Click += new System.EventHandler(this.BtnToAddToList_Click);
            // 
            // BtnGoBack
            // 
            this.BtnGoBack.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnGoBack.Location = new System.Drawing.Point(50, 297);
            this.BtnGoBack.Margin = new System.Windows.Forms.Padding(50, 30, 30, 10);
            this.BtnGoBack.Name = "BtnGoBack";
            this.BtnGoBack.Size = new System.Drawing.Size(94, 44);
            this.BtnGoBack.TabIndex = 7;
            this.BtnGoBack.Text = "Go Back";
            this.BtnGoBack.UseVisualStyleBackColor = false;
            this.BtnGoBack.Click += new System.EventHandler(this.BtnGoBack_Click);
            // 
            // RdoBtnCustomer
            // 
            this.RdoBtnCustomer.AutoSize = true;
            this.RdoBtnCustomer.BackColor = System.Drawing.Color.Khaki;
            this.RdoBtnCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.RdoBtnCustomer.Location = new System.Drawing.Point(420, 218);
            this.RdoBtnCustomer.Margin = new System.Windows.Forms.Padding(20, 20, 3, 3);
            this.RdoBtnCustomer.Name = "RdoBtnCustomer";
            this.RdoBtnCustomer.Size = new System.Drawing.Size(105, 26);
            this.RdoBtnCustomer.TabIndex = 9;
            this.RdoBtnCustomer.TabStop = true;
            this.RdoBtnCustomer.Text = "Customer";
            this.RdoBtnCustomer.UseVisualStyleBackColor = false;
            // 
            // RdoBtnAdmin
            // 
            this.RdoBtnAdmin.BackColor = System.Drawing.Color.Khaki;
            this.RdoBtnAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.RdoBtnAdmin.Location = new System.Drawing.Point(420, 135);
            this.RdoBtnAdmin.Margin = new System.Windows.Forms.Padding(20, 3, 3, 3);
            this.RdoBtnAdmin.Name = "RdoBtnAdmin";
            this.RdoBtnAdmin.Size = new System.Drawing.Size(104, 24);
            this.RdoBtnAdmin.TabIndex = 10;
            this.RdoBtnAdmin.Text = "Admin";
            this.RdoBtnAdmin.UseVisualStyleBackColor = false;
            // 
            // FormSignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormSignUp";
            this.Text = "FormSignUp";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormSignUp_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label LblName;
        private System.Windows.Forms.Label LblPassword;
        private System.Windows.Forms.TextBox TxtPassword;
        private System.Windows.Forms.TextBox TxtName;
        private System.Windows.Forms.Label LblRole;
        private System.Windows.Forms.Button BtnToAddToList;
        private System.Windows.Forms.Button BtnGoBack;
        private System.Windows.Forms.RadioButton RdoBtnAdmin;
        private System.Windows.Forms.RadioButton RdoBtnCustomer;
    }
}