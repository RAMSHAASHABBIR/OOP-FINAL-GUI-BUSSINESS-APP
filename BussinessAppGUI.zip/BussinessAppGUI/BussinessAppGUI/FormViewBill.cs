﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    public partial class FormViewBill : Form
    {
        public FormViewBill()
        {
            InitializeComponent();
            LblBill.Text =  OrdersDL.getList(Program.username).money.ToString() + " Rs";
        }

        private void LblBill_Click(object sender, EventArgs e)
        {
            MessageBox.Show(OrdersDL.getList(Program.username).money.ToString() + " Rs");
            LblBill.Visible = false;
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormCustomerMenu formCustomerMenu = new FormCustomerMenu();
            this.Hide();
            formCustomerMenu.Show();
        }

        private void FormViewBill_Load(object sender, EventArgs e)
        {

        }
    }
}
