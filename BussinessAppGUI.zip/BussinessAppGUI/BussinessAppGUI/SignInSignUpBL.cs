﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessAppGUI
{
    class SignInSignUpBL
    {
        private string Name;
        private string Password;
        private string Role;
        //this use to get name
        public string GetName()
        {
            return Name;
        }
        //this use to get password
        public string GetPassword()
        {
            return Password;
        }
        //this use to get role
        public string GetRole()
        {
            return Role;
        }
        //this constructor for sign in 
        public SignInSignUpBL(string name, string password)
        {
            this.Name = name;
            this.Password = password;
        }
        // this is constructor for sign up
        public SignInSignUpBL(string name, string password, string role)
        {
            this.Name = name;
            this.Password = password;
            this.Role = role;
        }
        }
    }