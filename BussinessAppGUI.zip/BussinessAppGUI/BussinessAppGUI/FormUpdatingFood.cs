﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace BussinessAppGUI
{
    public partial class FormUpdatingFood : Form
    {

        public FormUpdatingFood()
        {
            InitializeComponent();
        }

        private void BtnToUpdate_Click(object sender, EventArgs e)
        {
            string name1 = TxtUpdateName.Text;
            string price = TxtUpdatePrice.Text;
            bool checkascii = ValidationsBL.StringAsciiValidation(price);
            if ((!checkascii) || (TxtUpdateName.Text.Length == 0) || (TxtUpdatePrice.Text.Contains(" "))|| (TxtUpdateName.Text.Contains(" ")) || (TxtUpdatePrice.Text.Length == 0))
            {
                MessageBox.Show("Enter valid input");
            }
            else
            {

                MenuItemDL.products[FormUpdateProduct.check].SetName(name1);
                MenuItemDL.products[FormUpdateProduct.check].SetPrice(price);
                MenuItemDL.storeDataInFile();
                MessageBox.Show("Product is updated succesfully");
                FormAdminMenu formAdminMenu = new FormAdminMenu();
                this.Hide();
                formAdminMenu.Show();
            }
           
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormAdminMenu formAdminMenu = new FormAdminMenu();
            this.Hide();
            formAdminMenu.Show();
        }

        private void FormUpdatingFood_Load(object sender, EventArgs e)
        {

        }

        private void LblUpdateName_Click(object sender, EventArgs e)
        {

        }
    }
}
