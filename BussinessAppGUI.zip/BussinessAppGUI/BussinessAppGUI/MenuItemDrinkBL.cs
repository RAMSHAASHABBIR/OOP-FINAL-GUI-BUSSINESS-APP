﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessAppGUI
{
    class MenuItemDrinkBL : MenuItemBL
    {
        private string Productcatagorydrink;
        public MenuItemDrinkBL(string Productcatagorydrink, string Productname, string Price, string Stockquantity) : base(Productname, Price, Stockquantity)
        {
            this.Productcatagorydrink = Productcatagorydrink;
        }
        public override string toString()
        {
            string s = "product name: " + Productname + "  " + "product price:" + Price + "  " + "stock quantity:" + Stockquantity + "  " + "product catagory: " + Productcatagorydrink;
            return s;
        }
        //get type whether it is food or drink
        public override string getType()
        {
            return Productcatagorydrink;
        }
    }
}
