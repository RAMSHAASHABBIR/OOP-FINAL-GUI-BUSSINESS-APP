﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace BussinessAppGUI
{
    public partial class FormSignIn : Form
    {
        public FormSignIn()
        {
            InitializeComponent();
        }
        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormTitle formTitle = new FormTitle();
            this.Hide();
            formTitle.Show();
        }
        private void BtnToMenuPage_Click(object sender, EventArgs e)
        {
            string name = TxtSignInName.Text;
            string password = TxtSignInPassword.Text;
            SignInSignUpBL user = new SignInSignUpBL(name, password);
            string Role =  SignInSignUpDL. SignIn(user);
            if(Role == "Admin")
            {
                FormAdminMenu adminMenu = new FormAdminMenu();
                this.Hide();
                adminMenu.Show();
            }
            else if (Role == "Customer")
            {
                Program.username = name;
                OrdersDL.ReadOrders();
                FormCustomerMenu formcustomerMenu = new FormCustomerMenu();
                this.Hide();
                formcustomerMenu.Show();
            }

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FormSignIn_Load(object sender, EventArgs e)
        {

        }
        private void LblSignInPassword_Click(object sender, EventArgs e)
        {

        }
    }
}
