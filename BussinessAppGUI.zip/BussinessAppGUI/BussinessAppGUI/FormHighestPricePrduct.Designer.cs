﻿namespace BussinessAppGUI
{
    partial class FormHighestPricePrduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.GridProductOfHighestPrice = new System.Windows.Forms.DataGridView();
            this.BtnGoBack = new System.Windows.Forms.Button();
            this.LblHighestPrice = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridProductOfHighestPrice)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.ThemePage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.LblHighestPrice, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.GridProductOfHighestPrice, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // GridProductOfHighestPrice
            // 
            this.GridProductOfHighestPrice.BackgroundColor = System.Drawing.Color.Khaki;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Khaki;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Goldenrod;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridProductOfHighestPrice.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.GridProductOfHighestPrice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Khaki;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Goldenrod;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.GridProductOfHighestPrice.DefaultCellStyle = dataGridViewCellStyle2;
            this.GridProductOfHighestPrice.EnableHeadersVisualStyles = false;
            this.GridProductOfHighestPrice.Location = new System.Drawing.Point(163, 93);
            this.GridProductOfHighestPrice.Name = "GridProductOfHighestPrice";
            this.GridProductOfHighestPrice.ReadOnly = true;
            this.GridProductOfHighestPrice.RowHeadersVisible = false;
            this.GridProductOfHighestPrice.Size = new System.Drawing.Size(474, 174);
            this.GridProductOfHighestPrice.TabIndex = 13;
            this.GridProductOfHighestPrice.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridProductOfHighestPrice_CellContentClick);
            // 
            // BtnGoBack
            // 
            this.BtnGoBack.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnGoBack.Location = new System.Drawing.Point(644, 300);
            this.BtnGoBack.Margin = new System.Windows.Forms.Padding(4, 30, 30, 10);
            this.BtnGoBack.Name = "BtnGoBack";
            this.BtnGoBack.Size = new System.Drawing.Size(94, 44);
            this.BtnGoBack.TabIndex = 14;
            this.BtnGoBack.Text = "Go Back";
            this.BtnGoBack.UseVisualStyleBackColor = false;
            this.BtnGoBack.Click += new System.EventHandler(this.BtnGoBack_Click);
            // 
            // LblHighestPrice
            // 
            this.LblHighestPrice.AutoSize = true;
            this.LblHighestPrice.BackColor = System.Drawing.Color.Khaki;
            this.LblHighestPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.LblHighestPrice.Location = new System.Drawing.Point(220, 30);
            this.LblHighestPrice.Margin = new System.Windows.Forms.Padding(60, 30, 3, 0);
            this.LblHighestPrice.Name = "LblHighestPrice";
            this.LblHighestPrice.Size = new System.Drawing.Size(333, 26);
            this.LblHighestPrice.TabIndex = 15;
            this.LblHighestPrice.Text = "PRODUCT OF HIGHEST PRICE";
            // 
            // FormHighestPricePrduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormHighestPricePrduct";
            this.Text = "FormHighestPricePrduct";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormHighestPricePrduct_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridProductOfHighestPrice)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView GridProductOfHighestPrice;
        private System.Windows.Forms.Button BtnGoBack;
        private System.Windows.Forms.Label LblHighestPrice;
    }
}