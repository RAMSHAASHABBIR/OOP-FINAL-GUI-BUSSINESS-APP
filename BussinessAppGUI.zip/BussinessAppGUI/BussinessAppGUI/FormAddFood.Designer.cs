﻿namespace BussinessAppGUI
{
    partial class FormAddFood
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.LblFoodName = new System.Windows.Forms.Label();
            this.LblFoodStock = new System.Windows.Forms.Label();
            this.LblFoodPrice = new System.Windows.Forms.Label();
            this.TxtFoodName = new System.Windows.Forms.TextBox();
            this.TxtFoodPrice = new System.Windows.Forms.TextBox();
            this.TxtFoodStock = new System.Windows.Forms.TextBox();
            this.BtnGoBack = new System.Windows.Forms.Button();
            this.BtnToAddProductToList = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.ThemePage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.LblFoodName, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.LblFoodStock, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.LblFoodPrice, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.TxtFoodName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.TxtFoodPrice, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.TxtFoodStock, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnToAddProductToList, 1, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // LblFoodName
            // 
            this.LblFoodName.AutoSize = true;
            this.LblFoodName.BackColor = System.Drawing.Color.Khaki;
            this.LblFoodName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblFoodName.Location = new System.Drawing.Point(170, 30);
            this.LblFoodName.Margin = new System.Windows.Forms.Padding(170, 30, 20, 10);
            this.LblFoodName.Name = "LblFoodName";
            this.LblFoodName.Size = new System.Drawing.Size(182, 25);
            this.LblFoodName.TabIndex = 2;
            this.LblFoodName.Text = "Enter product name";
            // 
            // LblFoodStock
            // 
            this.LblFoodStock.AutoSize = true;
            this.LblFoodStock.BackColor = System.Drawing.Color.Khaki;
            this.LblFoodStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblFoodStock.Location = new System.Drawing.Point(170, 164);
            this.LblFoodStock.Margin = new System.Windows.Forms.Padding(170, 30, 20, 10);
            this.LblFoodStock.Name = "LblFoodStock";
            this.LblFoodStock.Size = new System.Drawing.Size(179, 25);
            this.LblFoodStock.TabIndex = 4;
            this.LblFoodStock.Text = "Enter product stock";
            // 
            // LblFoodPrice
            // 
            this.LblFoodPrice.AutoSize = true;
            this.LblFoodPrice.BackColor = System.Drawing.Color.Khaki;
            this.LblFoodPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblFoodPrice.Location = new System.Drawing.Point(170, 97);
            this.LblFoodPrice.Margin = new System.Windows.Forms.Padding(170, 30, 20, 10);
            this.LblFoodPrice.Name = "LblFoodPrice";
            this.LblFoodPrice.Size = new System.Drawing.Size(175, 25);
            this.LblFoodPrice.TabIndex = 3;
            this.LblFoodPrice.Text = "Enter product price";
            // 
            // TxtFoodName
            // 
            this.TxtFoodName.BackColor = System.Drawing.Color.Khaki;
            this.TxtFoodName.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtFoodName.Location = new System.Drawing.Point(420, 25);
            this.TxtFoodName.Margin = new System.Windows.Forms.Padding(20, 25, 10, 3);
            this.TxtFoodName.Name = "TxtFoodName";
            this.TxtFoodName.Size = new System.Drawing.Size(292, 36);
            this.TxtFoodName.TabIndex = 5;
            // 
            // TxtFoodPrice
            // 
            this.TxtFoodPrice.BackColor = System.Drawing.Color.Khaki;
            this.TxtFoodPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtFoodPrice.Location = new System.Drawing.Point(420, 92);
            this.TxtFoodPrice.Margin = new System.Windows.Forms.Padding(20, 25, 10, 3);
            this.TxtFoodPrice.Name = "TxtFoodPrice";
            this.TxtFoodPrice.Size = new System.Drawing.Size(292, 36);
            this.TxtFoodPrice.TabIndex = 6;
            // 
            // TxtFoodStock
            // 
            this.TxtFoodStock.BackColor = System.Drawing.Color.Khaki;
            this.TxtFoodStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtFoodStock.Location = new System.Drawing.Point(420, 159);
            this.TxtFoodStock.Margin = new System.Windows.Forms.Padding(20, 25, 10, 3);
            this.TxtFoodStock.Name = "TxtFoodStock";
            this.TxtFoodStock.Size = new System.Drawing.Size(292, 36);
            this.TxtFoodStock.TabIndex = 7;
            // 
            // BtnGoBack
            // 
            this.BtnGoBack.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnGoBack.Location = new System.Drawing.Point(50, 231);
            this.BtnGoBack.Margin = new System.Windows.Forms.Padding(50, 30, 30, 10);
            this.BtnGoBack.Name = "BtnGoBack";
            this.BtnGoBack.Size = new System.Drawing.Size(94, 44);
            this.BtnGoBack.TabIndex = 9;
            this.BtnGoBack.Text = "Go Back";
            this.BtnGoBack.UseVisualStyleBackColor = false;
            this.BtnGoBack.Click += new System.EventHandler(this.BtnGoBack_Click);
            // 
            // BtnToAddProductToList
            // 
            this.BtnToAddProductToList.BackColor = System.Drawing.Color.Khaki;
            this.BtnToAddProductToList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnToAddProductToList.Location = new System.Drawing.Point(617, 231);
            this.BtnToAddProductToList.Margin = new System.Windows.Forms.Padding(217, 30, 30, 10);
            this.BtnToAddProductToList.Name = "BtnToAddProductToList";
            this.BtnToAddProductToList.Size = new System.Drawing.Size(94, 44);
            this.BtnToAddProductToList.TabIndex = 10;
            this.BtnToAddProductToList.Text = "Enter";
            this.BtnToAddProductToList.UseVisualStyleBackColor = false;
            this.BtnToAddProductToList.Click += new System.EventHandler(this.BtnToAddProductToList_Click);
            // 
            // FormAddFood
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormAddFood";
            this.Text = "FormAddFood";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label LblFoodName;
        private System.Windows.Forms.Label LblFoodPrice;
        private System.Windows.Forms.Label LblFoodStock;
        private System.Windows.Forms.TextBox TxtFoodName;
        private System.Windows.Forms.TextBox TxtFoodPrice;
        private System.Windows.Forms.TextBox TxtFoodStock;
        private System.Windows.Forms.Button BtnGoBack;
        private System.Windows.Forms.Button BtnToAddProductToList;
    }
}