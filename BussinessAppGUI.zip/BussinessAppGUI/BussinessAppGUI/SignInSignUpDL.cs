﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
     class SignInSignUpDL
    {
       public static List<SignInSignUpBL> users = new List<SignInSignUpBL>();
        //this is used to check whether user exist or not
        public static string SignIn(SignInSignUpBL user)
        { 
            foreach (SignInSignUpBL storedUser in users)
            {
                if (user.GetName() == storedUser.GetName() && user.GetPassword() == storedUser.GetPassword())
                {
                    MessageBox.Show("Valid user");
                    return storedUser.GetRole();
                }
            }

            MessageBox.Show("User not exist");
            return null;
        }
        //this is used to add user to list
        public static void StoreDataInList( SignInSignUpBL user)
        {
            users.Add(user);
        } 
       
        //this is used to add user to file
       public static void StoreDataInFile(string path1, SignInSignUpBL userq)
        {
            StreamWriter file = new StreamWriter(path1);

            for (int i = 0; i < users.Count; i++) 
            {
                file.WriteLine(users[i].GetName()+ "," + users[i].GetPassword() + "," + users[i].GetRole());
            }
            file.Flush();
            file.Close();

        }
        //this is used to read data from file
        public static bool ReadData(string path1)

        {
            if (File.Exists(path1))
            {
                StreamReader file = new StreamReader(path1);
                string record;
                while ((record = file.ReadLine()) != null)
                {

                    string name = ParseData1(record, 1);
                    string password = ParseData1(record, 2);
                    string role = ParseData1(record, 3);
                    SignInSignUpBL user = new SignInSignUpBL(name, password, role);
                    StoreDataInList(user); 
                }
                file.Close();
                return true;
            }
            return false; 
        }
        //this is used in reading data from file
        public static string ParseData1(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length;
            x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }
        //this is used to verify that user not already exists
        public static bool ValidCustomerName(SignInSignUpBL userq)
        {
            bool ispresent = true;
            for(int i =0 ; i < users.Count;i++)
            {
                if(users[i].GetName() == userq.GetName())
                {
                    ispresent = false;
                    break;
                }
            }
            return ispresent;
        }
    }
}
