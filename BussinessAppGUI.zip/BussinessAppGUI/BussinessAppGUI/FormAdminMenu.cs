﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    public partial class FormAdminMenu : Form
    {
        public FormAdminMenu()
        {
            InitializeComponent();
        }

        private void BtnViewFood_Click(object sender, EventArgs e)
        {
            FormViewFoodUser formViewFoodUser = new FormViewFoodUser();
            this.Hide();
            formViewFoodUser.Show();
        }

        private void BtnUpdateProduct_Click(object sender, EventArgs e)
        {
            FormUpdateProduct formUpdateProduct = new FormUpdateProduct();
            this.Hide();
            formUpdateProduct.Show();
        }
        private void FormAdminMenu_Load(object sender, EventArgs e)
        {

        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormTitle formTitle = new FormTitle();
            this.Hide();
            formTitle.Show();
        }

        private void BtnAddDrink_Click(object sender, EventArgs e)
        {
            FormAddDrink formAddDrink = new FormAddDrink();
            this.Hide();
            formAddDrink.Show();
        }

        private void BtnViewDrink_Click(object sender, EventArgs e)
        {
            FormViewDrinkUser formViewDrinkUser = new FormViewDrinkUser();
             this.Hide();
            formViewDrinkUser.Show();
        }

        private void BtnAddFood_Click(object sender, EventArgs e)
        {
            FormAddFood formAddFood = new FormAddFood();
            this.Hide();
            formAddFood.Show();
        }

        private void BtnDeleteProduct_Click(object sender, EventArgs e)
        {
            FormDeleteProduct formDeleteProduct = new FormDeleteProduct();
            this.Hide();
            formDeleteProduct.Show();
        }

        private void BtnProductOrderSoon_Click(object sender, EventArgs e)
        {
            FormProductOrderSoon productOrderSoon = new FormProductOrderSoon();
            this.Hide();
            productOrderSoon.Show();
        }

        private void BtnAddingStock_Click(object sender, EventArgs e)
        {
            FormAddStock formAddStock = new FormAddStock();
            this.Hide();
            formAddStock.Show();
        }
    }
}
