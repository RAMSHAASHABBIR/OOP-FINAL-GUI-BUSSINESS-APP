﻿namespace BussinessAppGUI
{
    partial class FormSignIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.LblSignInName = new System.Windows.Forms.Label();
            this.LblSignInPassword = new System.Windows.Forms.Label();
            this.TxtSignInName = new System.Windows.Forms.TextBox();
            this.TxtSignInPassword = new System.Windows.Forms.TextBox();
            this.BtnToMenuPage = new System.Windows.Forms.Button();
            this.BtnGoBack = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Khaki;
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.TopPage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.LblSignInName, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.LblSignInPassword, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.TxtSignInName, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.TxtSignInPassword, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.BtnToMenuPage, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(843, 472);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // LblSignInName
            // 
            this.LblSignInName.AutoSize = true;
            this.LblSignInName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblSignInName.Location = new System.Drawing.Point(200, 27);
            this.LblSignInName.Margin = new System.Windows.Forms.Padding(200, 27, 20, 10);
            this.LblSignInName.Name = "LblSignInName";
            this.LblSignInName.Size = new System.Drawing.Size(155, 25);
            this.LblSignInName.TabIndex = 1;
            this.LblSignInName.Text = "Enter your name";
            // 
            // LblSignInPassword
            // 
            this.LblSignInPassword.AutoSize = true;
            this.LblSignInPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.LblSignInPassword.Location = new System.Drawing.Point(165, 93);
            this.LblSignInPassword.Margin = new System.Windows.Forms.Padding(165, 27, 20, 10);
            this.LblSignInPassword.Name = "LblSignInPassword";
            this.LblSignInPassword.Size = new System.Drawing.Size(190, 25);
            this.LblSignInPassword.TabIndex = 2;
            this.LblSignInPassword.Text = "Enter your password";
            this.LblSignInPassword.Click += new System.EventHandler(this.LblSignInPassword_Click);
            // 
            // TxtSignInName
            // 
            this.TxtSignInName.BackColor = System.Drawing.Color.Khaki;
            this.TxtSignInName.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtSignInName.Location = new System.Drawing.Point(441, 21);
            this.TxtSignInName.Margin = new System.Windows.Forms.Padding(20, 21, 10, 3);
            this.TxtSignInName.Name = "TxtSignInName";
            this.TxtSignInName.Size = new System.Drawing.Size(292, 36);
            this.TxtSignInName.TabIndex = 4;
            // 
            // TxtSignInPassword
            // 
            this.TxtSignInPassword.BackColor = System.Drawing.Color.Khaki;
            this.TxtSignInPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F);
            this.TxtSignInPassword.Location = new System.Drawing.Point(441, 87);
            this.TxtSignInPassword.Margin = new System.Windows.Forms.Padding(20, 21, 10, 3);
            this.TxtSignInPassword.Name = "TxtSignInPassword";
            this.TxtSignInPassword.Size = new System.Drawing.Size(292, 36);
            this.TxtSignInPassword.TabIndex = 3;
            // 
            // BtnToMenuPage
            // 
            this.BtnToMenuPage.BackColor = System.Drawing.Color.Khaki;
            this.BtnToMenuPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnToMenuPage.Location = new System.Drawing.Point(638, 162);
            this.BtnToMenuPage.Margin = new System.Windows.Forms.Padding(217, 30, 30, 10);
            this.BtnToMenuPage.Name = "BtnToMenuPage";
            this.BtnToMenuPage.Size = new System.Drawing.Size(94, 44);
            this.BtnToMenuPage.TabIndex = 7;
            this.BtnToMenuPage.Text = "Enter";
            this.BtnToMenuPage.UseVisualStyleBackColor = false;
            this.BtnToMenuPage.Click += new System.EventHandler(this.BtnToMenuPage_Click);
            // 
            // BtnGoBack
            // 
            this.BtnGoBack.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnGoBack.Location = new System.Drawing.Point(50, 162);
            this.BtnGoBack.Margin = new System.Windows.Forms.Padding(50, 30, 30, 10);
            this.BtnGoBack.Name = "BtnGoBack";
            this.BtnGoBack.Size = new System.Drawing.Size(94, 44);
            this.BtnGoBack.TabIndex = 8;
            this.BtnGoBack.Text = "Go Back";
            this.BtnGoBack.UseVisualStyleBackColor = false;
            this.BtnGoBack.Click += new System.EventHandler(this.BtnGoBack_Click);
            // 
            // FormSignIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(843, 472);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormSignIn";
            this.Text = "FormSignIn";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormSignIn_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label LblSignInName;
        private System.Windows.Forms.Label LblSignInPassword;
        private System.Windows.Forms.TextBox TxtSignInPassword;
        private System.Windows.Forms.TextBox TxtSignInName;
        private System.Windows.Forms.Button BtnToMenuPage;
        private System.Windows.Forms.Button BtnGoBack;
    }
}