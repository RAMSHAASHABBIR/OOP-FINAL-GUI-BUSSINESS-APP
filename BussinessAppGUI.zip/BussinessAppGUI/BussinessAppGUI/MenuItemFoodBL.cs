﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessAppGUI
{
    class MenuItemFoodBL : MenuItemBL
    {
        private string Productcatagoryfood;
        public MenuItemFoodBL(string Productcatagoryfood, string Productname, string Price, string Stockquantity) : base(Productname, Price, Stockquantity)
        {
            this.Productcatagoryfood = Productcatagoryfood;
        }
        //used to get whether it is food or drink
        public override string getType()
        {
            return Productcatagoryfood;
        }
        public override string toString()
        {

            string s = "product name: " + Productname + "  " + "product price:" + Price + "  " + "stock quantity:" + Stockquantity + "  " + "product catagory: " + Productcatagoryfood;
            return s;
        }
    }
}
