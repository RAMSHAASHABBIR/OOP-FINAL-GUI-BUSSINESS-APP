﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    public partial class FormViewDrinkUser : Form
    {
        public FormViewDrinkUser()
        {
            InitializeComponent();
        }
        private List<MenuItemBL> getDrinks()
        {
            List<MenuItemBL> drinks = new List<MenuItemBL>();
            foreach (var i in MenuItemDL.products)
            {
                if (i.GetType() == typeof(MenuItemDrinkBL))
                {

                    drinks.Add(i);
                }
            }
            return drinks;
        }

        private void FormViewDrinkUser_Load(object sender, EventArgs e)
        {
            GridPrintDrinkUser.DataSource = null;
            GridPrintDrinkUser.DataSource = getDrinks();
            GridPrintDrinkUser.Refresh();
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormCustomerMenu formCustomerMenu = new FormCustomerMenu();
            this.Hide();
            formCustomerMenu.Show();
        }
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
