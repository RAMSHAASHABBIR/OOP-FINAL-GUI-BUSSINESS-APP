﻿namespace BussinessAppGUI
{
    partial class FormPayBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.BtnYes = new System.Windows.Forms.RadioButton();
            this.BtnNo = new System.Windows.Forms.RadioButton();
            this.BtnEnter = new System.Windows.Forms.Button();
            this.LblPayBill = new System.Windows.Forms.Label();
            this.BtnGoBack = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.ThemePage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.BtnYes, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.BtnNo, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.BtnEnter, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.LblPayBill, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack, 0, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // BtnYes
            // 
            this.BtnYes.AutoSize = true;
            this.BtnYes.BackColor = System.Drawing.Color.Khaki;
            this.BtnYes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.BtnYes.Location = new System.Drawing.Point(195, 93);
            this.BtnYes.Margin = new System.Windows.Forms.Padding(35, 3, 3, 3);
            this.BtnYes.Name = "BtnYes";
            this.BtnYes.Size = new System.Drawing.Size(64, 29);
            this.BtnYes.TabIndex = 14;
            this.BtnYes.TabStop = true;
            this.BtnYes.Text = "Yes";
            this.BtnYes.UseVisualStyleBackColor = false;
            this.BtnYes.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // BtnNo
            // 
            this.BtnNo.AutoSize = true;
            this.BtnNo.BackColor = System.Drawing.Color.Khaki;
            this.BtnNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.BtnNo.Location = new System.Drawing.Point(195, 138);
            this.BtnNo.Margin = new System.Windows.Forms.Padding(35, 3, 3, 3);
            this.BtnNo.Name = "BtnNo";
            this.BtnNo.Size = new System.Drawing.Size(55, 29);
            this.BtnNo.TabIndex = 15;
            this.BtnNo.TabStop = true;
            this.BtnNo.Text = "No";
            this.BtnNo.UseVisualStyleBackColor = false;
            // 
            // BtnEnter
            // 
            this.BtnEnter.BackColor = System.Drawing.Color.Khaki;
            this.BtnEnter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnEnter.Location = new System.Drawing.Point(540, 190);
            this.BtnEnter.Margin = new System.Windows.Forms.Padding(380, 10, 3, 3);
            this.BtnEnter.Name = "BtnEnter";
            this.BtnEnter.Size = new System.Drawing.Size(97, 45);
            this.BtnEnter.TabIndex = 17;
            this.BtnEnter.Text = "Enter";
            this.BtnEnter.UseVisualStyleBackColor = false;
            this.BtnEnter.Click += new System.EventHandler(this.BtnEnter_Click);
            // 
            // LblPayBill
            // 
            this.LblPayBill.AutoSize = true;
            this.LblPayBill.BackColor = System.Drawing.Color.Khaki;
            this.LblPayBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.LblPayBill.Location = new System.Drawing.Point(190, 30);
            this.LblPayBill.Margin = new System.Windows.Forms.Padding(30, 30, 3, 0);
            this.LblPayBill.Name = "LblPayBill";
            this.LblPayBill.Size = new System.Drawing.Size(400, 26);
            this.LblPayBill.TabIndex = 13;
            this.LblPayBill.Text = "DO YOU REALLY WANT TO PAY BILL";
            // 
            // BtnGoBack
            // 
            this.BtnGoBack.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnGoBack.Location = new System.Drawing.Point(60, 190);
            this.BtnGoBack.Margin = new System.Windows.Forms.Padding(60, 10, 3, 3);
            this.BtnGoBack.Name = "BtnGoBack";
            this.BtnGoBack.Size = new System.Drawing.Size(97, 45);
            this.BtnGoBack.TabIndex = 18;
            this.BtnGoBack.Text = "Go Back";
            this.BtnGoBack.UseVisualStyleBackColor = false;
            this.BtnGoBack.Click += new System.EventHandler(this.BtnGoBack_Click);
            // 
            // FormPayBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormPayBill";
            this.Text = "FormPayBill";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormPayBill_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label LblPayBill;
        private System.Windows.Forms.RadioButton BtnYes;
        private System.Windows.Forms.RadioButton BtnNo;
        private System.Windows.Forms.Button BtnEnter;
        private System.Windows.Forms.Button BtnGoBack;
    }
}