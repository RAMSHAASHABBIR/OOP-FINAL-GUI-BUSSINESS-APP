﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessAppGUI
{
    //abstract class whose definitions are present in their children class
    abstract class MenuItemBL
    {
        private string productname;
        private string price;
        private string stockquantity;

        public string Productname { get => productname; set => productname = value; }
        public string Price { get => price; set => price = value; }
        public string Stockquantity { get => stockquantity; set => stockquantity = value; }

        public MenuItemBL(string Productname, string Price, string Stockquantity)
        {
            this.Productname = Productname;
            this.Price = Price;
            this.Stockquantity = Stockquantity;
        }
        public abstract string getType();
        public string GetName()
        {
            return Productname;
        }
        public string GetStockquantity()
        {
            return Stockquantity;
        }
        public string GetPrice()
        {
            return Price;
        }
        //used for setting all attributes
        public void SetName(string name)
        {
            this.Productname = name;
        }
        public void SetPrice(string price)
        {
            this.Price = price;
        }
        public void SetStockQuantity(string quantity)
        {
            this.Stockquantity = quantity;
        }

        public abstract string toString();
    }
}
