﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace BussinessAppGUI
{
    public partial class FormPlacingOrder : Form
    {
       
        public FormPlacingOrder()
        {
            InitializeComponent();
        }

        private void FormPlacingOrder_Load(object sender, EventArgs e)
        {
            dataGridPlaceOrder.DataSource = null;
            dataGridPlaceOrder.DataSource = MenuItemDL.products;
            dataGridPlaceOrder.Refresh();
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormCustomerMenu formCustomerMenu = new FormCustomerMenu();
            this.Hide();
            formCustomerMenu.Show();
        }
        private void dataGridPlaceOrder_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int s = dataGridPlaceOrder.SelectedCells[0].RowIndex;
            string name = (string)dataGridPlaceOrder.Rows[s].Cells[0].Value;
            DialogResult result = MessageBox.Show("would you like to buy " + name, "confirmation", MessageBoxButtons.YesNo);
            if(result == DialogResult.Yes)
            {
                
             
                OrdersBL order = OrdersDL.getList(Program.username);
                order.username = Program.username;
                float money =  MenuItemDL.Bill(name);
                order.money = money;
                order.Addingorder(name);
             
            }
           
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void dataGridPlaceOrder_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

    }
}
