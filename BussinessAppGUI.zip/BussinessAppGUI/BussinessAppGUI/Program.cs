﻿using System;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    internal static class Program
    {
        public static string username;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// 
        [STAThread]
        static void Main()
        {

            string path1 = " E:\\BussinessAppGUI\\BussinessAppGUI\\users.txt";
            string Pathcrud = "E:\\BussinessAppGUI\\BussinessAppGUI\\crud.txt";
            SignInSignUpDL.ReadData(path1);
            MenuItemDL.readData(Pathcrud);
            OrdersDL.ReadOrders();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormTitle());



        }
    }
}
