﻿using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Xml.Linq;

namespace BussinessAppGUI
{
    class OrdersDL
    {
        public static List<OrdersBL> orders = new List<OrdersBL>();
        public static OrdersBL getList(string username)
        {
            foreach (var i in orders)
            {
                if (i.username == username)
                {
                    return i;
                }
            }
            OrdersBL order = new OrdersBL();
            orders.Add(order);
            return order;
        }
        //this is used to write orders in file
        public static void WriteOrdersToFile()
        {
            string path = "E:\\BussinessAppGUI\\BussinessAppGUI\\order.txt";
            StreamWriter sw = new StreamWriter(path);
            foreach (var ordersBL in orders)
            {
                sw.WriteLine(ordersBL.username + "," + "," + ordersBL.GetListInCSVFormat());
                MessageBox.Show(ordersBL.GetListInCSVFormat());
            }
            sw.Close();
        }
        //this is used to read orders
        public static void ReadOrders()
        {
            string path = "E:\\BussinessAppGUI\\BussinessAppGUI\\order.txt";
            StreamReader sr = new StreamReader(path);
            string record = "";
            while ((record = sr.ReadLine()) != null)
            {
                if (record == "")
                {
                    continue;
                }
                string[] data = record.Split(',');
                string name = data[0];
                float money = float.Parse(data[1]);
                OrdersBL order = new OrdersBL(ReadRecord(data), name, money);
                orders.Add(order);
            }
            sr.Close();
        }
        //this is used to read records
        public static List<string> ReadRecord(string[] data)
        {
            List<string> orders = new List<string>();
            foreach (string item in data)
            {
                if (item != "")
                {
                    orders.Add(item);
                }
            }
            return orders;

        }
    }
}
