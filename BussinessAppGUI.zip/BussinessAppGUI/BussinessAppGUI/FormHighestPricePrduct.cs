﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    public partial class FormHighestPricePrduct : Form
    {
        public FormHighestPricePrduct()
        {
            InitializeComponent();
        }

        private void FormHighestPricePrduct_Load(object sender, EventArgs e)
        {
           
            GridProductOfHighestPrice.DataSource = null;
            GridProductOfHighestPrice.DataSource  = HighestPrice();
            GridProductOfHighestPrice.Refresh(); 
        }
        private List<MenuItemBL> HighestPrice()
        {
            List<MenuItemBL> highestprice = new List<MenuItemBL>();
            MenuItemBL m = MenuItemDL.HighestPrice();
            highestprice.Add(m);
            return highestprice;
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormCustomerMenu formCustomerMenu = new FormCustomerMenu();
            this.Hide();
            formCustomerMenu.Show();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void GridProductOfHighestPrice_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
