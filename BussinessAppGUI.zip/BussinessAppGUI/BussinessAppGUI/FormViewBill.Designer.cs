﻿namespace BussinessAppGUI
{
    partial class FormViewBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.LblViewBill = new System.Windows.Forms.Label();
            this.LblBill = new System.Windows.Forms.Label();
            this.BtnGoBack = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.ThemePage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.LblViewBill, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.LblBill, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.14021F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.14903F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.71075F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // LblViewBill
            // 
            this.LblViewBill.AutoSize = true;
            this.LblViewBill.BackColor = System.Drawing.Color.Khaki;
            this.LblViewBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.LblViewBill.Location = new System.Drawing.Point(20, 80);
            this.LblViewBill.Margin = new System.Windows.Forms.Padding(20, 80, 3, 0);
            this.LblViewBill.Name = "LblViewBill";
            this.LblViewBill.Size = new System.Drawing.Size(374, 39);
            this.LblViewBill.TabIndex = 0;
            this.LblViewBill.Text = "YOUR TOTAL BILL IS : ";
            // 
            // LblBill
            // 
            this.LblBill.AutoSize = true;
            this.LblBill.BackColor = System.Drawing.Color.Khaki;
            this.LblBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.LblBill.Location = new System.Drawing.Point(460, 80);
            this.LblBill.Margin = new System.Windows.Forms.Padding(60, 80, 3, 0);
            this.LblBill.Name = "LblBill";
            this.LblBill.Size = new System.Drawing.Size(109, 39);
            this.LblBill.TabIndex = 1;
            this.LblBill.Text = "label1";
            this.LblBill.Click += new System.EventHandler(this.LblBill_Click);
            // 
            // BtnGoBack
            // 
            this.BtnGoBack.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.BtnGoBack.Location = new System.Drawing.Point(50, 165);
            this.BtnGoBack.Margin = new System.Windows.Forms.Padding(50, 30, 30, 10);
            this.BtnGoBack.Name = "BtnGoBack";
            this.BtnGoBack.Size = new System.Drawing.Size(94, 44);
            this.BtnGoBack.TabIndex = 10;
            this.BtnGoBack.Text = "Go Back";
            this.BtnGoBack.UseVisualStyleBackColor = false;
            this.BtnGoBack.Click += new System.EventHandler(this.BtnGoBack_Click);
            // 
            // FormViewBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormViewBill";
            this.Text = "FormViewBill";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormViewBill_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label LblViewBill;
        private System.Windows.Forms.Label LblBill;
        private System.Windows.Forms.Button BtnGoBack;
    }
}