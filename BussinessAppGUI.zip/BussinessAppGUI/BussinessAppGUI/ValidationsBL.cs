﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessAppGUI
{
    class ValidationsBL
    {
        //this validation is used to confirm that passowrd only contain digits or alphabet no special characters
        public static bool AsciiValidattion(SignInSignUpBL user)
        {
            bool specialChar = true;

            for (int i = 0; i < user.GetPassword().Length; i++)
            {
                if ((user.GetPassword()[i] >= 48 && user.GetPassword()[i] <= 57) || (user.GetPassword()[i] >= 65 && user.GetPassword()[i] <= 90) || (user.GetPassword()[i] >= 97 && user.GetPassword()[i] <= 122))
                {
                    continue;
                }
                else
                {
                    specialChar = false;
                }
            }
            return specialChar;
        }
        //this validation is used to check that length of password should be 4
        public static bool LengthValidation(SignInSignUpBL user)
        {
            bool length = false;
            if (user.GetPassword().Length == 4)
            {
                length = true;
            }
            return length;
        }
        //this validation is used to check that user is not adding string where int is needed
        public static bool StringAsciiValidation(string name)
        {
            bool flag = true;
            for (int j = 0; j < name.Length; j++)
            {
                if (name[j] < 48 || name[j] > 57)
                {
                    flag=false;
                }
            }
            return flag;

        }
    }
}
