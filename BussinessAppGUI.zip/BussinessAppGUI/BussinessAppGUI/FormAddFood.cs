﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    public partial class FormAddFood : Form
    {
        public FormAddFood()
        {
            InitializeComponent();
        }

        private void BtnToAddProductToList_Click(object sender, EventArgs e)
        {
           
            bool check = false;
            bool check1 = false;
            string Productcatagory = "Food";
            string Productname = TxtFoodName.Text;
            string price = TxtFoodPrice.Text;
            string stockQuantity = TxtFoodStock.Text;
            check = ValidationsBL.StringAsciiValidation(price);
            check1 = ValidationsBL.StringAsciiValidation(stockQuantity);
            if ((!check) || (!check1) || (TxtFoodName.Text.Length == 0) || (TxtFoodName.Text.Contains(" ")))
            {
                MessageBox.Show("Enter valid input");
            }
            else
            {
                MenuItemFoodBL Food = new MenuItemFoodBL(Productcatagory, Productname, price, stockQuantity);
                MenuItemDL.AddingFoodtolist(Food);
                MenuItemDL.storeDataInFile();
                FormAdminMenu formAdminMenu = new FormAdminMenu();
                this.Hide();
                formAdminMenu.Show();
            }

        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormAdminMenu formAdminMenu = new FormAdminMenu();
            this.Hide();
            formAdminMenu.Show();
        }
    }
}
