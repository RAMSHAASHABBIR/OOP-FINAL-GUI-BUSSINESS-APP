﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace BussinessAppGUI
{
    class MenuItemDL
    {
        public static List<MenuItemBL> products = new List<MenuItemBL>();
        public static List<MenuItemBL> productToBeOrder = new List<MenuItemBL>();
        public static List<float> calculateTax = new List<float>();
        //used for adding drink to list
        public static void AddingDrinktolist(MenuItemDrinkBL itemDrink)
        {

            bool Checkproduct = false;
            for (int i = 0; i < products.Count; i++)
            {
                if (itemDrink.GetName() == products[i].GetName())
                {
                    Checkproduct = true;
                }
            }
            if (Checkproduct == false)
            {
                products.Add(itemDrink);
            }
            else
            {
                MessageBox.Show("Product already exist");
            }
        }
        //used for adding food to list
        public static void AddingFoodtolist(MenuItemFoodBL itemFood)
        {
            bool Checkproduct = false;
            for (int i = 0; i < products.Count; i++)
            {
                if (itemFood.GetName() == products[i].GetName())
                {
                    Checkproduct = true;
                }
            }
            if (Checkproduct == false)
            {
                products.Add(itemFood);
            }
            else
            {
                MessageBox.Show("Product already exist");

            }
        }
        //used for deleting product
        public static bool Deletingproduct(string Productname)
        {

            bool flag = false;
            for (int i = 0; i < products.Count; i++)
            {
                if (Productname == products[i].GetName())
                {
                    products.RemoveAt(i);
                    storeDataInFile();
                    flag = true;
                }
            }
            if (flag == false)
            {
                MessageBox.Show("Product doesn't exist");

            }
            return flag;
        }
        //used for adding new stock
        public static int CheckProductExistAddingStock(string name)
        {
            for (int j = 0; j < products.Count(); j++)
            {
                if (name == products[j].GetName())
                {
                    return j;
                }
            }
            return -1;
        }
        public static void AddingStock(string stock, int index)
        {
            bool check = ValidationsBL.StringAsciiValidation(stock);
            if (check == true && !stock.Contains(" ") && stock.Length != 0)
            {
                int sum = int.Parse(products[index].GetStockquantity()) + int.Parse(stock);
                products[index].SetStockQuantity(sum.ToString());
                MessageBox.Show("Stock is added successfully");
            }
            else
            {
                MessageBox.Show("Enter valid input");
            }
        }
        //used for seeing which product is highest
        public static MenuItemBL HighestPrice()
        {
            int i = 0;
            MenuItemBL menu = null;
            while (i < products.Count())
            {
                for (int j = 0; j < products.Count(); j++)
                {

                    if (int.Parse(products[i].GetPrice()) < int.Parse(products[j].GetPrice()))
                    {
                        menu = products[j];
                    }

                }
                i++;

            }
            return menu; ;
        }
        //used for calculating tax
        public static List<MenuItemBL> Tax()
        {
            List<MenuItemBL> listProduct = new List<MenuItemBL>();
            MenuItemBL menu = null;
            float Nowtotal = 0;
            float tax = 0;
            for (int j = 0; j < products.Count(); j++)
            {

                tax = int.Parse(products[j].GetPrice()) * 10 / 100;
                Nowtotal = int.Parse(products[j].GetPrice()) + tax;
                calculateTax.Add(Nowtotal);
                 menu = products[j];
                listProduct.Add(menu);
            }
            return listProduct;
        }
    
        //used for calculating bill
       public static float Bill(string name)
        {
            float Bill = 0;
            for (int j = 0; j < products.Count(); j++)
            { 
                if (name == products[j].GetName())
                {

                    float temp = float.Parse(products[j].GetPrice()) * 10 / 100;
                    Bill = Bill + float.Parse(products[j].GetPrice()) + temp;
                }
            }
            return Bill;
          
        }
        //used to store data in file
        public static void storeDataInFile()
        {
            string Pathcrud = "E:\\BussinessAppGUI\\BussinessAppGUI\\crud.txt";
            StreamWriter file = new StreamWriter(Pathcrud);

            for (int i = 0; i < products.Count; i++)
            {
                file.WriteLine(products[i].getType() + "," + products[i].GetName() + "," + products[i].GetPrice() + "," + products[i].GetStockquantity());
            }
            file.Flush();
            file.Close();
        }
        //used for reading data from file
        public static bool readData(string Pathcrud)

        {
            if (File.Exists(Pathcrud))
            {
                StreamReader file = new StreamReader(Pathcrud);
                string record;
                while ((record = file.ReadLine()) != null)
                {

                    string catagory = parseData1(record, 1);
                    string name = parseData1(record, 2);
                    string price = parseData1(record, 3);
                    string stock = parseData1(record, 4);
                    if (catagory == "Drink")
                    {
                        MenuItemDrinkBL drink = new MenuItemDrinkBL(catagory, name, price, stock);

                        AddingDrinktolist(drink);
                    }
                    else if (catagory == "Food")
                    {
                        MenuItemFoodBL food = new MenuItemFoodBL(catagory, name, price, stock);

                        AddingFoodtolist(food);
                    }
                }
                file.Close();
                return true;
            }
            return false;
        }
        public static string parseData1(string record, int field)
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length;
            x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];
                }
            }
            return item;
        }
    }
}
