﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessAppGUI
{
     class OrdersBL
    {
        public List<string> orders = new List<string>();
        public string username;
        public float money;
        public OrdersBL(List<string> orders,string username,float money) 
        {
            this.orders = orders;
            this.username = username;
            this.money = money;
        }
        public OrdersBL()
        {

        }
        public void Addingorder(string name)
        {
            orders.Add(name);
        }
        public string GetListInCSVFormat()
        {
            string s = "";
            foreach (string item in orders)
            {
                s += item + ',';
            }
            return s;
        }
    }
}
