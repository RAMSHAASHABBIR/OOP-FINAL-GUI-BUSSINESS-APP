﻿namespace BussinessAppGUI
{
    partial class FormTitle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.BtnSignUp = new System.Windows.Forms.Button();
            this.BtnSignIn = new System.Windows.Forms.Button();
            this.LblAppName = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.TopPage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.BtnSignUp, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.BtnSignIn, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.LblAppName, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(887, 499);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // BtnSignUp
            // 
            this.BtnSignUp.BackColor = System.Drawing.Color.Khaki;
            this.BtnSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.BtnSignUp.ForeColor = System.Drawing.Color.Black;
            this.BtnSignUp.Location = new System.Drawing.Point(218, 149);
            this.BtnSignUp.Margin = new System.Windows.Forms.Padding(350, 50, 25, 5);
            this.BtnSignUp.Name = "BtnSignUp";
            this.BtnSignUp.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.BtnSignUp.Size = new System.Drawing.Size(142, 69);
            this.BtnSignUp.TabIndex = 0;
            this.BtnSignUp.Text = "1. SignUp";
            this.BtnSignUp.UseVisualStyleBackColor = false;
            this.BtnSignUp.Click += new System.EventHandler(this.button1_Click);
            // 
            // BtnSignIn
            // 
            this.BtnSignIn.BackColor = System.Drawing.Color.Khaki;
            this.BtnSignIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.BtnSignIn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.BtnSignIn.Location = new System.Drawing.Point(218, 228);
            this.BtnSignIn.Margin = new System.Windows.Forms.Padding(350, 5, 25, 50);
            this.BtnSignIn.Name = "BtnSignIn";
            this.BtnSignIn.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.BtnSignIn.Size = new System.Drawing.Size(142, 69);
            this.BtnSignIn.TabIndex = 1;
            this.BtnSignIn.Text = "2. SignIn";
            this.BtnSignIn.UseVisualStyleBackColor = false;
            this.BtnSignIn.Click += new System.EventHandler(this.BtnSignIn_Click);
            // 
            // LblAppName
            // 
            this.LblAppName.AutoSize = true;
            this.LblAppName.BackColor = System.Drawing.Color.Khaki;
            this.LblAppName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.LblAppName.Location = new System.Drawing.Point(208, 30);
            this.LblAppName.Margin = new System.Windows.Forms.Padding(40, 30, 10, 20);
            this.LblAppName.Name = "LblAppName";
            this.LblAppName.Size = new System.Drawing.Size(462, 31);
            this.LblAppName.TabIndex = 3;
            this.LblAppName.Text = "ONLINE FOOD DELIVERY SYSTEM";
            this.LblAppName.Click += new System.EventHandler(this.LblAppName_Click);
            // 
            // FormTitle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(887, 499);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormTitle";
            this.Text = "FormTitle";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button BtnSignUp;
        private System.Windows.Forms.Button BtnSignIn;
        private System.Windows.Forms.Label LblAppName;
    }
}

