﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    public partial class FormAddStock : Form
    {
        public int index;
        public FormAddStock()
        {
            InitializeComponent();
        }

        private void BtnToAddStock_Click(object sender, EventArgs e)
        {
            string name = TxtFoodStockAdd.Text;
            if (!name.Contains(" ") && name.Length != 0)
            {
                index = MenuItemDL.CheckProductExistAddingStock(name);
                if (index == -1)
                {
                    MessageBox.Show("Product doesn't exists");

                }
                else
                {
                    MessageBox.Show("Product exists");
                    TxtFoodStockAdd.ReadOnly = true;
                    BtnGoBack.Visible = false;
                    BtnCheckProductToAdd.Visible = false;
                    LblFoodStockAdd.Visible = true;
                    TxtAddStockOfProduct.Visible = true;
                    BtnAddingStock.Visible = true;
                    BtnGoBack2.Visible = true;
                }
            }
            else
            {
                MessageBox.Show("Enter valid input");
            }
        }

        private void BtnAddingStock_Click(object sender, EventArgs e)
        {
            
            string stock = TxtAddStockOfProduct.Text;
            MenuItemDL.AddingStock(stock, index);
            MenuItemDL.storeDataInFile();
            FormAdminMenu formAdminMenu = new FormAdminMenu();
            this.Hide();
            formAdminMenu.Show();
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormAdminMenu formAdminMenu = new FormAdminMenu();
            this.Hide();
            formAdminMenu.Show();
        }

        private void BtnGoBack2_Click(object sender, EventArgs e)
        {
            FormAdminMenu formAdminMenu = new FormAdminMenu();
            this.Hide();
            formAdminMenu.Show();
        }

        private void FormAddStock_Load(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
