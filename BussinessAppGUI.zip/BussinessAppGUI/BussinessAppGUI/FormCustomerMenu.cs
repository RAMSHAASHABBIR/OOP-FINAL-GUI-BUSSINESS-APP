﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BussinessAppGUI
{
    public partial class FormCustomerMenu : Form
    {
        public FormCustomerMenu()
        {
            InitializeComponent();
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormTitle formTitle = new FormTitle();
            this.Hide();
            formTitle.Show();
        }

        private void BtnViewDrink_Click(object sender, EventArgs e)
        {
            FormViewDrinkUser menu = new FormViewDrinkUser();
            this.Hide();
            menu.Show();
        }

        private void BtnViewFood_Click(object sender, EventArgs e)
        {
            FormViewFoodUser menu = new FormViewFoodUser();
            this.Hide();
            menu.Show();
        }

        private void BtnHighestPrice_Click(object sender, EventArgs e)
        {
            FormHighestPricePrduct formHighestPricePrduct = new FormHighestPricePrduct();
            this.Hide();
            formHighestPricePrduct.Show();
        }

        private void BtnProductWithTax_Click(object sender, EventArgs e)
        {
            FormProductTax formProductTax = new FormProductTax();
            this.Hide();
            formProductTax.Show();
        }

        private void BtnPlaceOrder_Click(object sender, EventArgs e)
        {
            FormPlacingOrder formPlacingOrder = new FormPlacingOrder();
            this.Hide();
            formPlacingOrder.Show();
        }

        private void BtnViewBill_Click(object sender, EventArgs e)
        {
           // MessageBox.Show(OrdersDL.getList(Program.username).money.ToString());
            FormViewBill formViewBill = new FormViewBill();
            this.Hide();
            formViewBill.Show();
        }

        private void BtnShowingOrder_Click(object sender, EventArgs e)
        {
            FormViewOrders formViewOrders = new FormViewOrders();
            this.Hide();
            formViewOrders.Show();
        }

        private void BtnToPayBill_Click(object sender, EventArgs e)
        {
            FormPayBill formPayBill = new FormPayBill();
            this.Hide();
            formPayBill.Show();
        }
    }
}
