﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace BussinessAppGUI
{
    public partial class FormAddDrink : Form
    {
        public FormAddDrink()
        {
            InitializeComponent();
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormAdminMenu formAdminMenu = new FormAdminMenu();
            this.Hide();
            formAdminMenu.Show();
        }

        private void BtnToAddProductToList_Click(object sender, EventArgs e)
        {
         
            bool check = false;
            bool check1 = false;
            string Productcatagory = "Drink"; 
            string Productname = TxtDrinkName.Text;
            string price = TxtDrinkPrice.Text;
            string stockQuantity = TxtDrinkStock.Text;
           check = ValidationsBL.StringAsciiValidation(price);
            check1 = ValidationsBL.StringAsciiValidation(stockQuantity);
            if ((!check) || (!check1) || (TxtDrinkName.Text.Length == 0) || (TxtDrinkName.Text.Contains(" ")))
            {
                MessageBox.Show("Enter valid input");
            }
            else
            {
                MenuItemDrinkBL Drink = new MenuItemDrinkBL(Productcatagory, Productname, price, stockQuantity);
                MenuItemDL. AddingDrinktolist(Drink);
                MenuItemDL.storeDataInFile();
                FormAdminMenu formAdminMenu = new FormAdminMenu();
                this.Hide();
                formAdminMenu.Show();
            }

        }
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void TxtDrinkStock_TextChanged(object sender, EventArgs e)
        {

        }

        private void FormAddDrink_Load(object sender, EventArgs e)
        {

        }
    }
} 
