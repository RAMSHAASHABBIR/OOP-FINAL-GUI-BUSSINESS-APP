﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace BussinessAppGUI
{
    public partial class FormSignUp : Form
    {
        public FormSignUp()
        {
            InitializeComponent();
        }
        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            FormTitle formTitle = new FormTitle();
            this.Hide();
            formTitle.Show();
        }
       

        private void BtnToAddToList_Click(object sender, EventArgs e)
        {
            string path1 = "E:\\BussinessAppGUI\\BussinessAppGUI\\users.txt";
            string name = TxtName.Text;
            string password = TxtPassword.Text;
            
            if(TxtName.Text.Length != 0 && !TxtName.Text.Contains(" ")&& TxtPassword.Text.Length != 0 && !TxtPassword.Text.Contains(" "))
            {
               
                if (RdoBtnAdmin.Checked)
                {
                    SignInSignUpBL user = new SignInSignUpBL(name, password,"Admin");
                    if (ValidationsBL.AsciiValidattion(user)==true && ValidationsBL. LengthValidation(user) == true && SignInSignUpDL.ValidCustomerName(user) == true)
                    {
                        SignInSignUpDL.StoreDataInList(user);
                        SignInSignUpDL.StoreDataInFile(path1, user);
                        this.Hide();
                        FormTitle formTitle = new FormTitle();
                        formTitle.Show();
                    }
                    else
                    {
                        MessageBox.Show("Enter valid input");
                    }
                   
                }
                else if(RdoBtnCustomer.Checked)
                {
                    SignInSignUpBL user = new SignInSignUpBL(name, password, "Customer");
                    if (ValidationsBL.AsciiValidattion(user) == true && ValidationsBL.LengthValidation(user) == true && SignInSignUpDL. ValidCustomerName(user)==true)
                    {
                        SignInSignUpDL.StoreDataInList(user);
                        SignInSignUpDL.StoreDataInFile(path1, user);
                        this.Hide();
                        FormTitle formTitle = new FormTitle();
                        formTitle.Show();
                    }
                    else
                    {
                        MessageBox.Show("Enter valid input");
                    }
                }
                else
                {
                    MessageBox.Show("Enter valid input");
                }
            }
            else
            {
                MessageBox.Show("Enter valid input");
            }
        }
        private void FormSignUp_Load(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void LblName_Click(object sender, EventArgs e)
        {

        }

        private void LblPassword_Click(object sender, EventArgs e)
        {

        }
        private void TxtPassword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
