﻿namespace BussinessAppGUI
{
    partial class FormCustomerMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.BtnViewDrink = new System.Windows.Forms.Button();
            this.BtnViewFood = new System.Windows.Forms.Button();
            this.BtnHighestPrice = new System.Windows.Forms.Button();
            this.BtnProductWithTax = new System.Windows.Forms.Button();
            this.BtnPlaceOrder = new System.Windows.Forms.Button();
            this.BtnViewBill = new System.Windows.Forms.Button();
            this.BtnShowingOrder = new System.Windows.Forms.Button();
            this.BtnToPayBill = new System.Windows.Forms.Button();
            this.BtnGoBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::BussinessAppGUI.Properties.Resources.AdminPage;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.99999F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.00001F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.BtnViewDrink, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.BtnViewFood, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.BtnHighestPrice, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnProductWithTax, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.BtnPlaceOrder, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.BtnViewBill, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.BtnShowingOrder, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.BtnToPayBill, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.BtnGoBack, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // BtnViewDrink
            // 
            this.BtnViewDrink.BackColor = System.Drawing.Color.Khaki;
            this.BtnViewDrink.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.BtnViewDrink.Location = new System.Drawing.Point(3, 48);
            this.BtnViewDrink.Name = "BtnViewDrink";
            this.BtnViewDrink.Size = new System.Drawing.Size(260, 39);
            this.BtnViewDrink.TabIndex = 3;
            this.BtnViewDrink.Text = "View Drink Products";
            this.BtnViewDrink.UseVisualStyleBackColor = false;
            this.BtnViewDrink.Click += new System.EventHandler(this.BtnViewDrink_Click);
            // 
            // BtnViewFood
            // 
            this.BtnViewFood.BackColor = System.Drawing.Color.Khaki;
            this.BtnViewFood.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.BtnViewFood.Location = new System.Drawing.Point(3, 93);
            this.BtnViewFood.Name = "BtnViewFood";
            this.BtnViewFood.Size = new System.Drawing.Size(260, 39);
            this.BtnViewFood.TabIndex = 4;
            this.BtnViewFood.Text = "View Food Products";
            this.BtnViewFood.UseVisualStyleBackColor = false;
            this.BtnViewFood.Click += new System.EventHandler(this.BtnViewFood_Click);
            // 
            // BtnHighestPrice
            // 
            this.BtnHighestPrice.BackColor = System.Drawing.Color.Khaki;
            this.BtnHighestPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.BtnHighestPrice.Location = new System.Drawing.Point(3, 138);
            this.BtnHighestPrice.Name = "BtnHighestPrice";
            this.BtnHighestPrice.Size = new System.Drawing.Size(260, 39);
            this.BtnHighestPrice.TabIndex = 5;
            this.BtnHighestPrice.Text = "Product Of Highest Price";
            this.BtnHighestPrice.UseVisualStyleBackColor = false;
            this.BtnHighestPrice.Click += new System.EventHandler(this.BtnHighestPrice_Click);
            // 
            // BtnProductWithTax
            // 
            this.BtnProductWithTax.BackColor = System.Drawing.Color.Khaki;
            this.BtnProductWithTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.BtnProductWithTax.Location = new System.Drawing.Point(3, 183);
            this.BtnProductWithTax.Name = "BtnProductWithTax";
            this.BtnProductWithTax.Size = new System.Drawing.Size(260, 39);
            this.BtnProductWithTax.TabIndex = 6;
            this.BtnProductWithTax.Text = "View Product With Tax";
            this.BtnProductWithTax.UseVisualStyleBackColor = false;
            this.BtnProductWithTax.Click += new System.EventHandler(this.BtnProductWithTax_Click);
            // 
            // BtnPlaceOrder
            // 
            this.BtnPlaceOrder.BackColor = System.Drawing.Color.Khaki;
            this.BtnPlaceOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.BtnPlaceOrder.Location = new System.Drawing.Point(3, 228);
            this.BtnPlaceOrder.Name = "BtnPlaceOrder";
            this.BtnPlaceOrder.Size = new System.Drawing.Size(260, 39);
            this.BtnPlaceOrder.TabIndex = 7;
            this.BtnPlaceOrder.Text = "Place Your Order";
            this.BtnPlaceOrder.UseVisualStyleBackColor = false;
            this.BtnPlaceOrder.Click += new System.EventHandler(this.BtnPlaceOrder_Click);
            // 
            // BtnViewBill
            // 
            this.BtnViewBill.BackColor = System.Drawing.Color.Khaki;
            this.BtnViewBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.BtnViewBill.Location = new System.Drawing.Point(3, 273);
            this.BtnViewBill.Name = "BtnViewBill";
            this.BtnViewBill.Size = new System.Drawing.Size(260, 39);
            this.BtnViewBill.TabIndex = 8;
            this.BtnViewBill.Text = "View Bill";
            this.BtnViewBill.UseVisualStyleBackColor = false;
            this.BtnViewBill.Click += new System.EventHandler(this.BtnViewBill_Click);
            // 
            // BtnShowingOrder
            // 
            this.BtnShowingOrder.BackColor = System.Drawing.Color.Khaki;
            this.BtnShowingOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.BtnShowingOrder.Location = new System.Drawing.Point(3, 318);
            this.BtnShowingOrder.Name = "BtnShowingOrder";
            this.BtnShowingOrder.Size = new System.Drawing.Size(260, 39);
            this.BtnShowingOrder.TabIndex = 9;
            this.BtnShowingOrder.Text = "Showing Your Orders";
            this.BtnShowingOrder.UseVisualStyleBackColor = false;
            this.BtnShowingOrder.Click += new System.EventHandler(this.BtnShowingOrder_Click);
            // 
            // BtnToPayBill
            // 
            this.BtnToPayBill.BackColor = System.Drawing.Color.Khaki;
            this.BtnToPayBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.BtnToPayBill.Location = new System.Drawing.Point(3, 363);
            this.BtnToPayBill.Name = "BtnToPayBill";
            this.BtnToPayBill.Size = new System.Drawing.Size(260, 39);
            this.BtnToPayBill.TabIndex = 10;
            this.BtnToPayBill.Text = "To Pay Bill";
            this.BtnToPayBill.UseVisualStyleBackColor = false;
            this.BtnToPayBill.Click += new System.EventHandler(this.BtnToPayBill_Click);
            // 
            // BtnGoBack
            // 
            this.BtnGoBack.BackColor = System.Drawing.Color.Khaki;
            this.BtnGoBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.BtnGoBack.Location = new System.Drawing.Point(3, 408);
            this.BtnGoBack.Name = "BtnGoBack";
            this.BtnGoBack.Size = new System.Drawing.Size(260, 39);
            this.BtnGoBack.TabIndex = 11;
            this.BtnGoBack.Text = "Go Back";
            this.BtnGoBack.UseVisualStyleBackColor = false;
            this.BtnGoBack.Click += new System.EventHandler(this.BtnGoBack_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Khaki;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label1.Location = new System.Drawing.Point(71, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(71, 10, 3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "WELCOME";
            // 
            // FormCustomerMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Name = "FormCustomerMenu";
            this.Text = "FormCustomerMenu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnViewDrink;
        private System.Windows.Forms.Button BtnViewFood;
        private System.Windows.Forms.Button BtnHighestPrice;
        private System.Windows.Forms.Button BtnProductWithTax;
        private System.Windows.Forms.Button BtnPlaceOrder;
        private System.Windows.Forms.Button BtnViewBill;
        private System.Windows.Forms.Button BtnShowingOrder;
        private System.Windows.Forms.Button BtnToPayBill;
        private System.Windows.Forms.Button BtnGoBack;
    }
}